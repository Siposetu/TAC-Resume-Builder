export interface PersonalInfo {
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  address: string;
  city: string;
  state: string;
  zipCode: string;
  country: string;
  title: string;
  summary: string;
  website?: string;
  linkedin?: string;
  github?: string;
}

export interface Experience {
  id: string;
  company: string;
  position: string;
  location: string;
  startDate: string;
  endDate: string;
  current: boolean;
  description: string;
  achievements: string[];
}

export interface Education {
  id: string;
  institution: string;
  degree: string;
  fieldOfStudy: string;
  location: string;
  startDate: string;
  endDate: string;
  current: boolean;
  description: string;
  achievements: string[];
}

export interface Skill {
  id: string;
  name: string;
  level: number; // 1-5
}

export interface SkillCategory {
  id: string;
  name: string;
  skills: Skill[];
}

export interface Certificate {
  id: string;
  name: string;
  issuer: string;
  date: string;
  description?: string;
  url?: string;
}

export interface Language {
  id: string;
  name: string;
  proficiency: 'Elementary' | 'Limited Working' | 'Professional Working' | 'Full Professional' | 'Native';
}

export interface Project {
  id: string;
  name: string;
  description: string;
  startDate: string;
  endDate: string;
  current: boolean;
  url?: string;
  achievements: string[];
}

export interface ResumeData {
  personalInfo: PersonalInfo;
  experiences: Experience[];
  educations: Education[];
  skillCategories: SkillCategory[];
  certificates: Certificate[];
  languages: Language[];
  projects: Project[];
  template: TemplateType;
  color: ColorScheme;
}

export type TemplateType = 'modern' | 'professional' | 'creative';

export type ColorScheme = 'blue' | 'teal' | 'purple' | 'gray' | 'green' | 'red';

export interface AIGenerationRequest {
  type: 'summary' | 'experience' | 'achievement' | 'skill';
  context: string;
  jobTitle?: string;
  industry?: string;
  yearsOfExperience?: number;
}

export interface AIGenerationResponse {
  content: string;
  alternatives?: string[];
  suggestions?: string[];
}