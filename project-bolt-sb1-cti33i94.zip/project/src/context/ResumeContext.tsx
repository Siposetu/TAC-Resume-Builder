import React, { createContext, useContext, useEffect, useState } from 'react';
import { ResumeData, TemplateType, ColorScheme } from '../types';
import { loadResumeData, saveResumeData, generateUniqueId } from '../utils/storage';

// Default resume data
const defaultResumeData: ResumeData = {
  personalInfo: {
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    address: '',
    city: '',
    state: '',
    zipCode: '',
    country: '',
    title: '',
    summary: '',
    website: '',
    linkedin: '',
    github: ''
  },
  experiences: [],
  educations: [],
  skillCategories: [],
  certificates: [],
  languages: [],
  projects: [],
  template: 'modern',
  color: 'blue'
};

interface ResumeContextProps {
  resumeData: ResumeData;
  updatePersonalInfo: (info: Partial<ResumeData['personalInfo']>) => void;
  addExperience: (experience: Omit<ResumeData['experiences'][0], 'id'>) => void;
  updateExperience: (id: string, experience: Partial<Omit<ResumeData['experiences'][0], 'id'>>) => void;
  removeExperience: (id: string) => void;
  addEducation: (education: Omit<ResumeData['educations'][0], 'id'>) => void;
  updateEducation: (id: string, education: Partial<Omit<ResumeData['educations'][0], 'id'>>) => void;
  removeEducation: (id: string) => void;
  addSkillCategory: (category: Omit<ResumeData['skillCategories'][0], 'id' | 'skills'>) => void;
  updateSkillCategory: (id: string, category: Partial<Omit<ResumeData['skillCategories'][0], 'id' | 'skills'>>) => void;
  removeSkillCategory: (id: string) => void;
  addSkill: (categoryId: string, skill: Omit<ResumeData['skillCategories'][0]['skills'][0], 'id'>) => void;
  updateSkill: (categoryId: string, skillId: string, skill: Partial<Omit<ResumeData['skillCategories'][0]['skills'][0], 'id'>>) => void;
  removeSkill: (categoryId: string, skillId: string) => void;
  addCertificate: (certificate: Omit<ResumeData['certificates'][0], 'id'>) => void;
  updateCertificate: (id: string, certificate: Partial<Omit<ResumeData['certificates'][0], 'id'>>) => void;
  removeCertificate: (id: string) => void;
  addLanguage: (language: Omit<ResumeData['languages'][0], 'id'>) => void;
  updateLanguage: (id: string, language: Partial<Omit<ResumeData['languages'][0], 'id'>>) => void;
  removeLanguage: (id: string) => void;
  addProject: (project: Omit<ResumeData['projects'][0], 'id'>) => void;
  updateProject: (id: string, project: Partial<Omit<ResumeData['projects'][0], 'id'>>) => void;
  removeProject: (id: string) => void;
  updateTemplate: (template: TemplateType) => void;
  updateColor: (color: ColorScheme) => void;
  resetResumeData: () => void;
  updateResumeData: (data: ResumeData) => void;
}

const ResumeContext = createContext<ResumeContextProps | undefined>(undefined);

export const ResumeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [resumeData, setResumeData] = useState<ResumeData>(defaultResumeData);

  // Load resume data from localStorage on initial render
  useEffect(() => {
    const savedData = loadResumeData();
    if (savedData) {
      setResumeData(savedData);
    }
  }, []);

  // Save resume data to localStorage whenever it changes
  useEffect(() => {
    saveResumeData(resumeData);
  }, [resumeData]);

  // Update entire resume data
  const updateResumeData = (data: ResumeData) => {
    setResumeData(data);
  };

  // Update personal information
  const updatePersonalInfo = (info: Partial<ResumeData['personalInfo']>) => {
    setResumeData(prev => ({
      ...prev,
      personalInfo: {
        ...prev.personalInfo,
        ...info
      }
    }));
  };

  // Experience management
  const addExperience = (experience: Omit<ResumeData['experiences'][0], 'id'>) => {
    const newExperience = {
      id: generateUniqueId(),
      ...experience
    };
    setResumeData(prev => ({
      ...prev,
      experiences: [newExperience, ...prev.experiences]
    }));
  };

  const updateExperience = (id: string, experience: Partial<Omit<ResumeData['experiences'][0], 'id'>>) => {
    setResumeData(prev => ({
      ...prev,
      experiences: prev.experiences.map(exp => 
        exp.id === id ? { ...exp, ...experience } : exp
      )
    }));
  };

  const removeExperience = (id: string) => {
    setResumeData(prev => ({
      ...prev,
      experiences: prev.experiences.filter(exp => exp.id !== id)
    }));
  };

  // Education management
  const addEducation = (education: Omit<ResumeData['educations'][0], 'id'>) => {
    const newEducation = {
      id: generateUniqueId(),
      ...education
    };
    setResumeData(prev => ({
      ...prev,
      educations: [newEducation, ...prev.educations]
    }));
  };

  const updateEducation = (id: string, education: Partial<Omit<ResumeData['educations'][0], 'id'>>) => {
    setResumeData(prev => ({
      ...prev,
      educations: prev.educations.map(edu => 
        edu.id === id ? { ...edu, ...education } : edu
      )
    }));
  };

  const removeEducation = (id: string) => {
    setResumeData(prev => ({
      ...prev,
      educations: prev.educations.filter(edu => edu.id !== id)
    }));
  };

  // Skill category management
  const addSkillCategory = (category: Omit<ResumeData['skillCategories'][0], 'id' | 'skills'>) => {
    const newCategory = {
      id: generateUniqueId(),
      ...category,
      skills: []
    };
    setResumeData(prev => ({
      ...prev,
      skillCategories: [...prev.skillCategories, newCategory]
    }));
  };

  const updateSkillCategory = (id: string, category: Partial<Omit<ResumeData['skillCategories'][0], 'id' | 'skills'>>) => {
    setResumeData(prev => ({
      ...prev,
      skillCategories: prev.skillCategories.map(cat => 
        cat.id === id ? { ...cat, ...category } : cat
      )
    }));
  };

  const removeSkillCategory = (id: string) => {
    setResumeData(prev => ({
      ...prev,
      skillCategories: prev.skillCategories.filter(cat => cat.id !== id)
    }));
  };

  // Skill management
  const addSkill = (categoryId: string, skill: Omit<ResumeData['skillCategories'][0]['skills'][0], 'id'>) => {
    const newSkill = {
      id: generateUniqueId(),
      ...skill
    };
    setResumeData(prev => ({
      ...prev,
      skillCategories: prev.skillCategories.map(cat => 
        cat.id === categoryId ? { ...cat, skills: [...cat.skills, newSkill] } : cat
      )
    }));
  };

  const updateSkill = (categoryId: string, skillId: string, skill: Partial<Omit<ResumeData['skillCategories'][0]['skills'][0], 'id'>>) => {
    setResumeData(prev => ({
      ...prev,
      skillCategories: prev.skillCategories.map(cat => 
        cat.id === categoryId ? 
          { 
            ...cat, 
            skills: cat.skills.map(s => s.id === skillId ? { ...s, ...skill } : s) 
          } : 
          cat
      )
    }));
  };

  const removeSkill = (categoryId: string, skillId: string) => {
    setResumeData(prev => ({
      ...prev,
      skillCategories: prev.skillCategories.map(cat => 
        cat.id === categoryId ? 
          { 
            ...cat, 
            skills: cat.skills.filter(s => s.id !== skillId) 
          } : 
          cat
      )
    }));
  };

  // Certificate management
  const addCertificate = (certificate: Omit<ResumeData['certificates'][0], 'id'>) => {
    const newCertificate = {
      id: generateUniqueId(),
      ...certificate
    };
    setResumeData(prev => ({
      ...prev,
      certificates: [...prev.certificates, newCertificate]
    }));
  };

  const updateCertificate = (id: string, certificate: Partial<Omit<ResumeData['certificates'][0], 'id'>>) => {
    setResumeData(prev => ({
      ...prev,
      certificates: prev.certificates.map(cert => 
        cert.id === id ? { ...cert, ...certificate } : cert
      )
    }));
  };

  const removeCertificate = (id: string) => {
    setResumeData(prev => ({
      ...prev,
      certificates: prev.certificates.filter(cert => cert.id !== id)
    }));
  };

  // Language management
  const addLanguage = (language: Omit<ResumeData['languages'][0], 'id'>) => {
    const newLanguage = {
      id: generateUniqueId(),
      ...language
    };
    setResumeData(prev => ({
      ...prev,
      languages: [...prev.languages, newLanguage]
    }));
  };

  const updateLanguage = (id: string, language: Partial<Omit<ResumeData['languages'][0], 'id'>>) => {
    setResumeData(prev => ({
      ...prev,
      languages: prev.languages.map(lang => 
        lang.id === id ? { ...lang, ...language } : lang
      )
    }));
  };

  const removeLanguage = (id: string) => {
    setResumeData(prev => ({
      ...prev,
      languages: prev.languages.filter(lang => lang.id !== id)
    }));
  };

  // Project management
  const addProject = (project: Omit<ResumeData['projects'][0], 'id'>) => {
    const newProject = {
      id: generateUniqueId(),
      ...project
    };
    setResumeData(prev => ({
      ...prev,
      projects: [...prev.projects, newProject]
    }));
  };

  const updateProject = (id: string, project: Partial<Omit<ResumeData['projects'][0], 'id'>>) => {
    setResumeData(prev => ({
      ...prev,
      projects: prev.projects.map(proj => 
        proj.id === id ? { ...proj, ...project } : proj
      )
    }));
  };

  const removeProject = (id: string) => {
    setResumeData(prev => ({
      ...prev,
      projects: prev.projects.filter(proj => proj.id !== id)
    }));
  };

  // Template management
  const updateTemplate = (template: TemplateType) => {
    setResumeData(prev => ({
      ...prev,
      template
    }));
  };

  // Color management
  const updateColor = (color: ColorScheme) => {
    setResumeData(prev => ({
      ...prev,
      color
    }));
  };

  // Reset resume data
  const resetResumeData = () => {
    setResumeData(defaultResumeData);
  };

  return (
    <ResumeContext.Provider
      value={{
        resumeData,
        updatePersonalInfo,
        addExperience,
        updateExperience,
        removeExperience,
        addEducation,
        updateEducation,
        removeEducation,
        addSkillCategory,
        updateSkillCategory,
        removeSkillCategory,
        addSkill,
        updateSkill,
        removeSkill,
        addCertificate,
        updateCertificate,
        removeCertificate,
        addLanguage,
        updateLanguage,
        removeLanguage,
        addProject,
        updateProject,
        removeProject,
        updateTemplate,
        updateColor,
        resetResumeData,
        updateResumeData
      }}
    >
      {children}
    </ResumeContext.Provider>
  );
};

export const useResume = () => {
  const context = useContext(ResumeContext);
  if (context === undefined) {
    throw new Error('useResume must be used within a ResumeProvider');
  }
  return context;
};