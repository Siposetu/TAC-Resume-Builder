import React from 'react';
import { ResumeData } from '../../types';

interface ModernTemplateProps {
  resumeData: ResumeData;
}

const ModernTemplate: React.FC<ModernTemplateProps> = ({ resumeData }) => {
  const { personalInfo, experiences, educations, skillCategories, certificates, languages, projects, color } = resumeData;
  
  // Color mapping
  const colorMap = {
    blue: 'bg-primary-600 text-primary-600 border-primary-600',
    teal: 'bg-secondary-600 text-secondary-600 border-secondary-600',
    purple: 'bg-accent-600 text-accent-600 border-accent-600',
    gray: 'bg-gray-600 text-gray-600 border-gray-600',
    green: 'bg-success-600 text-success-600 border-success-600',
    red: 'bg-error-600 text-error-600 border-error-600',
  };
  
  const themeColor = colorMap[color];
  const bgColor = themeColor.split(' ')[0];
  const textColor = themeColor.split(' ')[1];
  const borderColor = themeColor.split(' ')[2];
  
  return (
    <div className="w-full bg-white shadow-md text-sm leading-normal">
      {/* Header */}
      <header className={`${bgColor} text-white p-6`}>
        <h1 className="text-3xl font-bold">{personalInfo.firstName} {personalInfo.lastName}</h1>
        <p className="text-lg mt-1">{personalInfo.title}</p>
        
        <div className="flex flex-wrap gap-3 mt-3 text-xs">
          {personalInfo.email && (
            <div className="flex items-center">
              <span className="font-medium">Email:</span>
              <span className="ml-1">{personalInfo.email}</span>
            </div>
          )}
          
          {personalInfo.phone && (
            <div className="flex items-center">
              <span className="font-medium">Phone:</span>
              <span className="ml-1">{personalInfo.phone}</span>
            </div>
          )}
          
          {personalInfo.city && personalInfo.state && (
            <div className="flex items-center">
              <span className="font-medium">Location:</span>
              <span className="ml-1">{personalInfo.city}, {personalInfo.state}</span>
            </div>
          )}
          
          {personalInfo.linkedin && (
            <div className="flex items-center">
              <span className="font-medium">LinkedIn:</span>
              <span className="ml-1">{personalInfo.linkedin}</span>
            </div>
          )}
          
          {personalInfo.website && (
            <div className="flex items-center">
              <span className="font-medium">Website:</span>
              <span className="ml-1">{personalInfo.website}</span>
            </div>
          )}
        </div>
      </header>
      
      <div className="p-6 space-y-6">
        {/* Summary */}
        {personalInfo.summary && (
          <section>
            <h2 className={`text-lg font-bold ${textColor} border-b ${borderColor} pb-1 mb-3`}>PROFESSIONAL SUMMARY</h2>
            <p className="text-gray-700">{personalInfo.summary}</p>
          </section>
        )}
        
        {/* Experience */}
        {experiences.length > 0 && (
          <section>
            <h2 className={`text-lg font-bold ${textColor} border-b ${borderColor} pb-1 mb-3`}>WORK EXPERIENCE</h2>
            <div className="space-y-4">
              {experiences.map(exp => (
                <div key={exp.id}>
                  <div className="flex justify-between items-baseline">
                    <h3 className="font-bold text-gray-800">{exp.position}</h3>
                    <span className="text-xs text-gray-600">
                      {exp.startDate} - {exp.current ? 'Present' : exp.endDate}
                    </span>
                  </div>
                  <p className="text-gray-700">{exp.company}, {exp.location}</p>
                  {exp.description && <p className="mt-2 text-gray-700">{exp.description}</p>}
                  
                  {exp.achievements.length > 0 && (
                    <ul className="mt-2 list-disc list-inside text-gray-700">
                      {exp.achievements.map((achievement, idx) => (
                        <li key={idx}>{achievement}</li>
                      ))}
                    </ul>
                  )}
                </div>
              ))}
            </div>
          </section>
        )}
        
        {/* Education */}
        {educations.length > 0 && (
          <section>
            <h2 className={`text-lg font-bold ${textColor} border-b ${borderColor} pb-1 mb-3`}>EDUCATION</h2>
            <div className="space-y-4">
              {educations.map(edu => (
                <div key={edu.id}>
                  <div className="flex justify-between items-baseline">
                    <h3 className="font-bold text-gray-800">{edu.degree}{edu.fieldOfStudy ? ` in ${edu.fieldOfStudy}` : ''}</h3>
                    <span className="text-xs text-gray-600">
                      {edu.startDate} - {edu.current ? 'Present' : edu.endDate}
                    </span>
                  </div>
                  <p className="text-gray-700">{edu.institution}, {edu.location}</p>
                  {edu.description && <p className="mt-2 text-gray-700">{edu.description}</p>}
                  
                  {edu.achievements.length > 0 && (
                    <ul className="mt-2 list-disc list-inside text-gray-700">
                      {edu.achievements.map((achievement, idx) => (
                        <li key={idx}>{achievement}</li>
                      ))}
                    </ul>
                  )}
                </div>
              ))}
            </div>
          </section>
        )}
        
        {/* Skills */}
        {skillCategories.length > 0 && (
          <section>
            <h2 className={`text-lg font-bold ${textColor} border-b ${borderColor} pb-1 mb-3`}>SKILLS</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {skillCategories.map(category => (
                <div key={category.id}>
                  <h3 className="font-bold text-gray-800 mb-2">{category.name}</h3>
                  <div className="space-y-2">
                    {category.skills.map(skill => (
                      <div key={skill.id} className="flex items-center">
                        <span className="text-gray-700 flex-grow">{skill.name}</span>
                        <div className="flex">
                          {[1, 2, 3, 4, 5].map(level => (
                            <div 
                              key={level}
                              className={`h-2 w-4 mx-0.5 rounded-sm ${
                                level <= skill.level ? bgColor : 'bg-gray-200'
                              }`}
                            />
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </section>
        )}
        
        {/* Certificates */}
        {certificates.length > 0 && (
          <section>
            <h2 className={`text-lg font-bold ${textColor} border-b ${borderColor} pb-1 mb-3`}>CERTIFICATIONS</h2>
            <div className="space-y-2">
              {certificates.map(cert => (
                <div key={cert.id} className="flex justify-between">
                  <div>
                    <span className="font-medium text-gray-800">{cert.name}</span>
                    <span className="text-gray-700 mx-1">-</span>
                    <span className="text-gray-700">{cert.issuer}</span>
                  </div>
                  <span className="text-gray-600 text-xs">{cert.date}</span>
                </div>
              ))}
            </div>
          </section>
        )}
        
        {/* Languages */}
        {languages.length > 0 && (
          <section>
            <h2 className={`text-lg font-bold ${textColor} border-b ${borderColor} pb-1 mb-3`}>LANGUAGES</h2>
            <div className="grid grid-cols-2 gap-2">
              {languages.map(lang => (
                <div key={lang.id} className="flex justify-between">
                  <span className="text-gray-700">{lang.name}</span>
                  <span className="text-gray-600 text-xs">{lang.proficiency}</span>
                </div>
              ))}
            </div>
          </section>
        )}
        
        {/* Projects */}
        {projects.length > 0 && (
          <section>
            <h2 className={`text-lg font-bold ${textColor} border-b ${borderColor} pb-1 mb-3`}>PROJECTS</h2>
            <div className="space-y-4">
              {projects.map(project => (
                <div key={project.id}>
                  <div className="flex justify-between items-baseline">
                    <h3 className="font-bold text-gray-800">{project.name}</h3>
                    <span className="text-xs text-gray-600">
                      {project.startDate} - {project.current ? 'Present' : project.endDate}
                    </span>
                  </div>
                  <p className="mt-1 text-gray-700">{project.description}</p>
                  
                  {project.achievements.length > 0 && (
                    <ul className="mt-2 list-disc list-inside text-gray-700">
                      {project.achievements.map((achievement, idx) => (
                        <li key={idx}>{achievement}</li>
                      ))}
                    </ul>
                  )}
                </div>
              ))}
            </div>
          </section>
        )}
      </div>
    </div>
  );
};

export default ModernTemplate;