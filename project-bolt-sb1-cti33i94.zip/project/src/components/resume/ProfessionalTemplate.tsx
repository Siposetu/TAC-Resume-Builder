import React from 'react';
import { ResumeData } from '../../types';

interface ProfessionalTemplateProps {
  resumeData: ResumeData;
}

const ProfessionalTemplate: React.FC<ProfessionalTemplateProps> = ({ resumeData }) => {
  const { personalInfo, experiences, educations, skillCategories, certificates, languages, projects, color } = resumeData;
  
  // Color mapping
  const colorMap = {
    blue: 'bg-primary-600 text-primary-600 border-primary-600',
    teal: 'bg-secondary-600 text-secondary-600 border-secondary-600',
    purple: 'bg-accent-600 text-accent-600 border-accent-600',
    gray: 'bg-gray-600 text-gray-600 border-gray-600',
    green: 'bg-success-600 text-success-600 border-success-600',
    red: 'bg-error-600 text-error-600 border-error-600',
  };
  
  const themeColor = colorMap[color];
  const textColor = themeColor.split(' ')[1];
  
  return (
    <div className="w-full bg-white shadow-md text-sm leading-normal">
      {/* Header */}
      <header className="p-6 text-center border-b-2 border-gray-300">
        <h1 className={`text-3xl font-bold ${textColor}`}>{personalInfo.firstName} {personalInfo.lastName}</h1>
        <p className="text-lg text-gray-700 mt-1">{personalInfo.title}</p>
        
        <div className="flex flex-wrap justify-center gap-4 mt-3 text-xs">
          {personalInfo.email && (
            <div className="flex items-center">
              <span className="font-medium">Email:</span>
              <span className="ml-1">{personalInfo.email}</span>
            </div>
          )}
          
          {personalInfo.phone && (
            <div className="flex items-center">
              <span className="font-medium">Phone:</span>
              <span className="ml-1">{personalInfo.phone}</span>
            </div>
          )}
          
          {personalInfo.city && personalInfo.state && (
            <div className="flex items-center">
              <span className="font-medium">Location:</span>
              <span className="ml-1">{personalInfo.city}, {personalInfo.state}</span>
            </div>
          )}
          
          {personalInfo.linkedin && (
            <div className="flex items-center">
              <span className="font-medium">LinkedIn:</span>
              <span className="ml-1">{personalInfo.linkedin}</span>
            </div>
          )}
          
          {personalInfo.website && (
            <div className="flex items-center">
              <span className="font-medium">Website:</span>
              <span className="ml-1">{personalInfo.website}</span>
            </div>
          )}
        </div>
      </header>
      
      <div className="p-6 space-y-6">
        {/* Summary */}
        {personalInfo.summary && (
          <section>
            <h2 className={`text-lg font-bold ${textColor} mb-2`}>PROFESSIONAL SUMMARY</h2>
            <div className="border-l-4 pl-4 border-gray-300">
              <p className="text-gray-700">{personalInfo.summary}</p>
            </div>
          </section>
        )}
        
        {/* Experience */}
        {experiences.length > 0 && (
          <section>
            <h2 className={`text-lg font-bold ${textColor} mb-2`}>WORK EXPERIENCE</h2>
            <div className="space-y-4">
              {experiences.map(exp => (
                <div key={exp.id} className="border-l-4 pl-4 border-gray-300">
                  <div className="flex justify-between items-baseline">
                    <h3 className="font-bold text-gray-800">{exp.position}</h3>
                    <span className="text-xs text-gray-600">
                      {exp.startDate} - {exp.current ? 'Present' : exp.endDate}
                    </span>
                  </div>
                  <p className={`${textColor} font-medium`}>{exp.company}, {exp.location}</p>
                  {exp.description && <p className="mt-2 text-gray-700">{exp.description}</p>}
                  
                  {exp.achievements.length > 0 && (
                    <ul className="mt-2 list-disc list-outside ml-4 text-gray-700">
                      {exp.achievements.map((achievement, idx) => (
                        <li key={idx}>{achievement}</li>
                      ))}
                    </ul>
                  )}
                </div>
              ))}
            </div>
          </section>
        )}
        
        {/* Education */}
        {educations.length > 0 && (
          <section>
            <h2 className={`text-lg font-bold ${textColor} mb-2`}>EDUCATION</h2>
            <div className="space-y-4">
              {educations.map(edu => (
                <div key={edu.id} className="border-l-4 pl-4 border-gray-300">
                  <div className="flex justify-between items-baseline">
                    <h3 className="font-bold text-gray-800">{edu.degree}{edu.fieldOfStudy ? ` in ${edu.fieldOfStudy}` : ''}</h3>
                    <span className="text-xs text-gray-600">
                      {edu.startDate} - {edu.current ? 'Present' : edu.endDate}
                    </span>
                  </div>
                  <p className={`${textColor} font-medium`}>{edu.institution}, {edu.location}</p>
                  {edu.description && <p className="mt-2 text-gray-700">{edu.description}</p>}
                  
                  {edu.achievements.length > 0 && (
                    <ul className="mt-2 list-disc list-outside ml-4 text-gray-700">
                      {edu.achievements.map((achievement, idx) => (
                        <li key={idx}>{achievement}</li>
                      ))}
                    </ul>
                  )}
                </div>
              ))}
            </div>
          </section>
        )}
        
        {/* Skills */}
        {skillCategories.length > 0 && (
          <section>
            <h2 className={`text-lg font-bold ${textColor} mb-2`}>SKILLS</h2>
            <div className="border-l-4 pl-4 border-gray-300">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {skillCategories.map(category => (
                  <div key={category.id}>
                    <h3 className="font-bold text-gray-800 mb-2">{category.name}</h3>
                    <div className="flex flex-wrap gap-2">
                      {category.skills.map(skill => (
                        <span 
                          key={skill.id} 
                          className={`inline-block px-3 py-1 rounded-full text-xs ${
                            skill.level >= 4 ? 'bg-gray-800 text-white' : 'bg-gray-200 text-gray-800'
                          }`}
                        >
                          {skill.name}
                        </span>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>
        )}
        
        {/* Two column layout for Certificates and Languages */}
        {(certificates.length > 0 || languages.length > 0) && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Certificates */}
            {certificates.length > 0 && (
              <section>
                <h2 className={`text-lg font-bold ${textColor} mb-2`}>CERTIFICATIONS</h2>
                <div className="border-l-4 pl-4 border-gray-300 space-y-2">
                  {certificates.map(cert => (
                    <div key={cert.id}>
                      <p className="font-medium text-gray-800">{cert.name}</p>
                      <div className="flex justify-between text-xs">
                        <span className="text-gray-700">{cert.issuer}</span>
                        <span className="text-gray-600">{cert.date}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </section>
            )}
            
            {/* Languages */}
            {languages.length > 0 && (
              <section>
                <h2 className={`text-lg font-bold ${textColor} mb-2`}>LANGUAGES</h2>
                <div className="border-l-4 pl-4 border-gray-300 space-y-2">
                  {languages.map(lang => (
                    <div key={lang.id} className="flex justify-between">
                      <span className="font-medium text-gray-800">{lang.name}</span>
                      <span className="text-gray-600 text-xs">{lang.proficiency}</span>
                    </div>
                  ))}
                </div>
              </section>
            )}
          </div>
        )}
        
        {/* Projects */}
        {projects.length > 0 && (
          <section>
            <h2 className={`text-lg font-bold ${textColor} mb-2`}>PROJECTS</h2>
            <div className="space-y-4">
              {projects.map(project => (
                <div key={project.id} className="border-l-4 pl-4 border-gray-300">
                  <div className="flex justify-between items-baseline">
                    <h3 className="font-bold text-gray-800">{project.name}</h3>
                    <span className="text-xs text-gray-600">
                      {project.startDate} - {project.current ? 'Present' : project.endDate}
                    </span>
                  </div>
                  <p className="mt-1 text-gray-700">{project.description}</p>
                  
                  {project.achievements.length > 0 && (
                    <ul className="mt-2 list-disc list-outside ml-4 text-gray-700">
                      {project.achievements.map((achievement, idx) => (
                        <li key={idx}>{achievement}</li>
                      ))}
                    </ul>
                  )}
                </div>
              ))}
            </div>
          </section>
        )}
      </div>
    </div>
  );
};

export default ProfessionalTemplate;