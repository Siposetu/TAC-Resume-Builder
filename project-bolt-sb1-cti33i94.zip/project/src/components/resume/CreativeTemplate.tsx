import React from 'react';
import { ResumeData } from '../../types';

interface CreativeTemplateProps {
  resumeData: ResumeData;
}

const CreativeTemplate: React.FC<CreativeTemplateProps> = ({ resumeData }) => {
  const { personalInfo, experiences, educations, skillCategories, certificates, languages, projects, color } = resumeData;
  
  // Color mapping
  const colorMap = {
    blue: 'bg-primary-600 text-primary-600 border-primary-600',
    teal: 'bg-secondary-600 text-secondary-600 border-secondary-600',
    purple: 'bg-accent-600 text-accent-600 border-accent-600',
    gray: 'bg-gray-600 text-gray-600 border-gray-600',
    green: 'bg-success-600 text-success-600 border-success-600',
    red: 'bg-error-600 text-error-600 border-error-600',
  };
  
  const themeColor = colorMap[color];
  const bgColor = themeColor.split(' ')[0];
  const textColor = themeColor.split(' ')[1];
  const borderColor = themeColor.split(' ')[2];
  
  return (
    <div className="w-full bg-white shadow-md text-sm leading-normal">
      <div className="grid grid-cols-3">
        {/* Sidebar */}
        <div className={`${bgColor} text-white p-6 col-span-1`}>
          <div className="mb-8 text-center">
            <h1 className="text-2xl font-bold">{personalInfo.firstName}</h1>
            <h1 className="text-2xl font-bold">{personalInfo.lastName}</h1>
            <p className="text-md mt-2 opacity-80">{personalInfo.title}</p>
          </div>
          
          <div className="space-y-6">
            {/* Contact */}
            <section>
              <h2 className="text-md font-bold border-b border-white/30 pb-1 mb-3">CONTACT</h2>
              <div className="space-y-2 text-xs">
                {personalInfo.email && (
                  <div>
                    <p className="font-medium">Email</p>
                    <p>{personalInfo.email}</p>
                  </div>
                )}
                
                {personalInfo.phone && (
                  <div>
                    <p className="font-medium">Phone</p>
                    <p>{personalInfo.phone}</p>
                  </div>
                )}
                
                {personalInfo.city && personalInfo.state && (
                  <div>
                    <p className="font-medium">Location</p>
                    <p>{personalInfo.city}, {personalInfo.state}</p>
                  </div>
                )}
                
                {personalInfo.linkedin && (
                  <div>
                    <p className="font-medium">LinkedIn</p>
                    <p>{personalInfo.linkedin}</p>
                  </div>
                )}
                
                {personalInfo.website && (
                  <div>
                    <p className="font-medium">Website</p>
                    <p>{personalInfo.website}</p>
                  </div>
                )}
              </div>
            </section>
            
            {/* Skills */}
            {skillCategories.length > 0 && (
              <section>
                <h2 className="text-md font-bold border-b border-white/30 pb-1 mb-3">SKILLS</h2>
                <div className="space-y-3">
                  {skillCategories.map(category => (
                    <div key={category.id} className="mb-3">
                      <h3 className="font-medium text-sm mb-1">{category.name}</h3>
                      <div className="space-y-1.5">
                        {category.skills.map(skill => (
                          <div key={skill.id} className="flex items-center">
                            <span className="text-xs">{skill.name}</span>
                            <div className="ml-auto flex">
                              {[1, 2, 3, 4, 5].map(level => (
                                <div 
                                  key={level}
                                  className={`h-1.5 w-3 mx-0.5 rounded-sm ${
                                    level <= skill.level ? 'bg-white' : 'bg-white/30'
                                  }`}
                                />
                              ))}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </section>
            )}
            
            {/* Languages */}
            {languages.length > 0 && (
              <section>
                <h2 className="text-md font-bold border-b border-white/30 pb-1 mb-3">LANGUAGES</h2>
                <div className="space-y-1.5">
                  {languages.map(lang => (
                    <div key={lang.id} className="flex justify-between text-xs">
                      <span>{lang.name}</span>
                      <span className="opacity-80">{lang.proficiency}</span>
                    </div>
                  ))}
                </div>
              </section>
            )}
            
            {/* Certificates */}
            {certificates.length > 0 && (
              <section>
                <h2 className="text-md font-bold border-b border-white/30 pb-1 mb-3">CERTIFICATIONS</h2>
                <div className="space-y-2">
                  {certificates.map(cert => (
                    <div key={cert.id} className="text-xs">
                      <p className="font-medium">{cert.name}</p>
                      <div className="flex justify-between opacity-80">
                        <span>{cert.issuer}</span>
                        <span>{cert.date}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </section>
            )}
          </div>
        </div>
        
        {/* Main Content */}
        <div className="col-span-2 p-6 space-y-6">
          {/* Summary */}
          {personalInfo.summary && (
            <section>
              <h2 className={`text-lg font-bold ${textColor} mb-3 flex items-center`}>
                <span className={`inline-block w-8 h-0.5 ${bgColor} mr-2`}></span>
                ABOUT ME
              </h2>
              <p className="text-gray-700">{personalInfo.summary}</p>
            </section>
          )}
          
          {/* Experience */}
          {experiences.length > 0 && (
            <section>
              <h2 className={`text-lg font-bold ${textColor} mb-3 flex items-center`}>
                <span className={`inline-block w-8 h-0.5 ${bgColor} mr-2`}></span>
                WORK EXPERIENCE
              </h2>
              <div className="space-y-4">
                {experiences.map(exp => (
                  <div key={exp.id} className="relative pl-6 pb-4">
                    <div className={`absolute left-0 top-0 bottom-0 w-[2px] ${bgColor}`}></div>
                    <div className={`absolute left-[-4px] top-1.5 w-3 h-3 rounded-full ${bgColor}`}></div>
                    
                    <div className="flex justify-between items-baseline">
                      <h3 className="font-bold text-gray-800">{exp.position}</h3>
                      <span className="text-xs text-gray-600">
                        {exp.startDate} - {exp.current ? 'Present' : exp.endDate}
                      </span>
                    </div>
                    <p className={`${textColor} font-medium`}>{exp.company}, {exp.location}</p>
                    {exp.description && <p className="mt-2 text-gray-700">{exp.description}</p>}
                    
                    {exp.achievements.length > 0 && (
                      <ul className="mt-2 space-y-1 text-gray-700">
                        {exp.achievements.map((achievement, idx) => (
                          <li key={idx} className="flex items-start">
                            <span className={`inline-block w-1.5 h-1.5 rounded-full ${bgColor} mt-1.5 mr-2 flex-shrink-0`}></span>
                            <span>{achievement}</span>
                          </li>
                        ))}
                      </ul>
                    )}
                  </div>
                ))}
              </div>
            </section>
          )}
          
          {/* Education */}
          {educations.length > 0 && (
            <section>
              <h2 className={`text-lg font-bold ${textColor} mb-3 flex items-center`}>
                <span className={`inline-block w-8 h-0.5 ${bgColor} mr-2`}></span>
                EDUCATION
              </h2>
              <div className="space-y-4">
                {educations.map(edu => (
                  <div key={edu.id} className="relative pl-6 pb-4">
                    <div className={`absolute left-0 top-0 bottom-0 w-[2px] ${bgColor}`}></div>
                    <div className={`absolute left-[-4px] top-1.5 w-3 h-3 rounded-full ${bgColor}`}></div>
                    
                    <div className="flex justify-between items-baseline">
                      <h3 className="font-bold text-gray-800">{edu.degree}{edu.fieldOfStudy ? ` in ${edu.fieldOfStudy}` : ''}</h3>
                      <span className="text-xs text-gray-600">
                        {edu.startDate} - {edu.current ? 'Present' : edu.endDate}
                      </span>
                    </div>
                    <p className={`${textColor} font-medium`}>{edu.institution}, {edu.location}</p>
                    {edu.description && <p className="mt-2 text-gray-700">{edu.description}</p>}
                    
                    {edu.achievements.length > 0 && (
                      <ul className="mt-2 space-y-1 text-gray-700">
                        {edu.achievements.map((achievement, idx) => (
                          <li key={idx} className="flex items-start">
                            <span className={`inline-block w-1.5 h-1.5 rounded-full ${bgColor} mt-1.5 mr-2 flex-shrink-0`}></span>
                            <span>{achievement}</span>
                          </li>
                        ))}
                      </ul>
                    )}
                  </div>
                ))}
              </div>
            </section>
          )}
          
          {/* Projects */}
          {projects.length > 0 && (
            <section>
              <h2 className={`text-lg font-bold ${textColor} mb-3 flex items-center`}>
                <span className={`inline-block w-8 h-0.5 ${bgColor} mr-2`}></span>
                PROJECTS
              </h2>
              <div className="space-y-4">
                {projects.map(project => (
                  <div key={project.id} className="relative pl-6 pb-4">
                    <div className={`absolute left-0 top-0 bottom-0 w-[2px] ${bgColor}`}></div>
                    <div className={`absolute left-[-4px] top-1.5 w-3 h-3 rounded-full ${bgColor}`}></div>
                    
                    <div className="flex justify-between items-baseline">
                      <h3 className="font-bold text-gray-800">{project.name}</h3>
                      <span className="text-xs text-gray-600">
                        {project.startDate} - {project.current ? 'Present' : project.endDate}
                      </span>
                    </div>
                    <p className="mt-1 text-gray-700">{project.description}</p>
                    
                    {project.achievements.length > 0 && (
                      <ul className="mt-2 space-y-1 text-gray-700">
                        {project.achievements.map((achievement, idx) => (
                          <li key={idx} className="flex items-start">
                            <span className={`inline-block w-1.5 h-1.5 rounded-full ${bgColor} mt-1.5 mr-2 flex-shrink-0`}></span>
                            <span>{achievement}</span>
                          </li>
                        ))}
                      </ul>
                    )}
                  </div>
                ))}
              </div>
            </section>
          )}
        </div>
      </div>
    </div>
  );
};

export default CreativeTemplate;