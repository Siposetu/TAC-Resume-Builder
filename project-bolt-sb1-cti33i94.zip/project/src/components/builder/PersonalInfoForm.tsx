import React, { useState, useEffect } from 'react';
import { useResume } from '../../context/ResumeContext';
import { generateAIContent } from '../../utils/mockAI';
import { MessageSquare, Sparkles } from 'lucide-react';

const PersonalInfoForm: React.FC = () => {
  const { resumeData, updatePersonalInfo } = useResume();
  const { personalInfo } = resumeData;
  
  const [isGeneratingSummary, setIsGeneratingSummary] = useState(false);
  const [aiSuggestions, setAiSuggestions] = useState<string[]>([]);
  
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    updatePersonalInfo({ [name]: value });
  };
  
  const generateSummary = async () => {
    if (!personalInfo.title) {
      alert('Please enter a job title first');
      return;
    }
    
    setIsGeneratingSummary(true);
    
    try {
      const context = `${personalInfo.title} ${personalInfo.firstName} ${personalInfo.lastName}`;
      const response = await generateAIContent({
        type: 'summary',
        context,
        jobTitle: personalInfo.title
      });
      
      updatePersonalInfo({ summary: response.content });
      setAiSuggestions(response.alternatives || []);
    } catch (error) {
      console.error('Error generating summary:', error);
    } finally {
      setIsGeneratingSummary(false);
    }
  };
  
  const applySuggestion = (suggestion: string) => {
    updatePersonalInfo({ summary: suggestion });
  };
  
  return (
    <div className="animate-fade-in space-y-6">
      <div className="card p-6">
        <h3 className="section-title">Personal Information</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="form-group">
            <label htmlFor="firstName" className="form-label">First Name</label>
            <input
              type="text"
              id="firstName"
              name="firstName"
              value={personalInfo.firstName}
              onChange={handleInputChange}
              className="input"
              placeholder="John"
            />
          </div>
          
          <div className="form-group">
            <label htmlFor="lastName" className="form-label">Last Name</label>
            <input
              type="text"
              id="lastName"
              name="lastName"
              value={personalInfo.lastName}
              onChange={handleInputChange}
              className="input"
              placeholder="Doe"
            />
          </div>
          
          <div className="form-group">
            <label htmlFor="email" className="form-label">Email</label>
            <input
              type="email"
              id="email"
              name="email"
              value={personalInfo.email}
              onChange={handleInputChange}
              className="input"
              placeholder="john.doe@example.com"
            />
          </div>
          
          <div className="form-group">
            <label htmlFor="phone" className="form-label">Phone</label>
            <input
              type="tel"
              id="phone"
              name="phone"
              value={personalInfo.phone}
              onChange={handleInputChange}
              className="input"
              placeholder="(555) 123-4567"
            />
          </div>
          
          <div className="form-group">
            <label htmlFor="city" className="form-label">City</label>
            <input
              type="text"
              id="city"
              name="city"
              value={personalInfo.city}
              onChange={handleInputChange}
              className="input"
              placeholder="San Francisco"
            />
          </div>
          
          <div className="form-group">
            <label htmlFor="state" className="form-label">State</label>
            <input
              type="text"
              id="state"
              name="state"
              value={personalInfo.state}
              onChange={handleInputChange}
              className="input"
              placeholder="CA"
            />
          </div>
          
          <div className="form-group md:col-span-2">
            <label htmlFor="title" className="form-label">Professional Title</label>
            <input
              type="text"
              id="title"
              name="title"
              value={personalInfo.title}
              onChange={handleInputChange}
              className="input"
              placeholder="Full Stack Developer"
            />
            <p className="form-helper">Enter your current or desired job title</p>
          </div>
          
          <div className="form-group md:col-span-2">
            <label htmlFor="summary" className="form-label flex items-center">
              Professional Summary
              <button
                type="button"
                onClick={generateSummary}
                disabled={isGeneratingSummary}
                className="ml-2 inline-flex items-center px-2 py-1 text-xs font-medium rounded bg-accent-100 text-accent-700 hover:bg-accent-200 transition-colors"
              >
                {isGeneratingSummary ? (
                  <>Generating...</>
                ) : (
                  <>
                    <Sparkles className="h-3 w-3 mr-1" />
                    Generate with AI
                  </>
                )}
              </button>
            </label>
            <textarea
              id="summary"
              name="summary"
              value={personalInfo.summary}
              onChange={handleInputChange}
              className="textarea h-32"
              placeholder="A brief summary of your professional background, skills, and career objectives."
            />
            <p className="form-helper">
              Provide a concise overview of your skills, experience, and career goals. This is the first thing employers will read.
            </p>
          </div>
          
          {aiSuggestions.length > 0 && (
            <div className="md:col-span-2 mt-2">
              <div className="bg-gray-50 p-4 rounded-md border border-gray-200">
                <h4 className="text-sm font-medium text-gray-900 mb-2 flex items-center">
                  <MessageSquare className="h-4 w-4 mr-1 text-accent-600" />
                  AI Suggestions
                </h4>
                <div className="space-y-2">
                  {aiSuggestions.map((suggestion, index) => (
                    <div key={index} className="bg-white p-3 rounded border border-gray-200 text-sm">
                      {suggestion}
                      <div className="mt-2">
                        <button
                          type="button"
                          onClick={() => applySuggestion(suggestion)}
                          className="text-xs font-medium text-accent-600 hover:text-accent-800"
                        >
                          Apply this suggestion
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
          
          <div className="form-group">
            <label htmlFor="linkedin" className="form-label">LinkedIn (optional)</label>
            <input
              type="url"
              id="linkedin"
              name="linkedin"
              value={personalInfo.linkedin || ''}
              onChange={handleInputChange}
              className="input"
              placeholder="https://linkedin.com/in/johndoe"
            />
          </div>
          
          <div className="form-group">
            <label htmlFor="website" className="form-label">Website (optional)</label>
            <input
              type="url"
              id="website"
              name="website"
              value={personalInfo.website || ''}
              onChange={handleInputChange}
              className="input"
              placeholder="https://johndoe.com"
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default PersonalInfoForm;