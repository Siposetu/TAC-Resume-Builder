import React, { useState } from 'react';
import { useResume } from '../../context/ResumeContext';
import { generateAIContent } from '../../utils/mockAI';
import { Experience } from '../../types';
import { generateUniqueId } from '../../utils/storage';
import { Sparkles, Plus, Trash, Edit, MessageSquare, Check, X } from 'lucide-react';

const ExperienceForm: React.FC = () => {
  const { resumeData, addExperience, updateExperience, removeExperience } = useResume();
  const { experiences } = resumeData;
  
  const [isAdding, setIsAdding] = useState(false);
  const [isEditing, setIsEditing] = useState<string | null>(null);
  const [isGeneratingDescription, setIsGeneratingDescription] = useState(false);
  const [isGeneratingAchievement, setIsGeneratingAchievement] = useState(false);
  const [aiSuggestions, setAiSuggestions] = useState<string[]>([]);
  
  const [formData, setFormData] = useState<Omit<Experience, 'id'>>({
    company: '',
    position: '',
    location: '',
    startDate: '',
    endDate: '',
    current: false,
    description: '',
    achievements: ['']
  });
  
  const resetForm = () => {
    setFormData({
      company: '',
      position: '',
      location: '',
      startDate: '',
      endDate: '',
      current: false,
      description: '',
      achievements: ['']
    });
    setAiSuggestions([]);
  };
  
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  const handleCheckboxChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, checked } = e.target;
    setFormData(prev => ({ ...prev, [name]: checked }));
  };
  
  const handleAchievementChange = (index: number, value: string) => {
    setFormData(prev => {
      const newAchievements = [...prev.achievements];
      newAchievements[index] = value;
      return { ...prev, achievements: newAchievements };
    });
  };
  
  const addAchievementField = () => {
    setFormData(prev => ({
      ...prev,
      achievements: [...prev.achievements, '']
    }));
  };
  
  const removeAchievementField = (index: number) => {
    setFormData(prev => {
      const newAchievements = [...prev.achievements];
      newAchievements.splice(index, 1);
      return { ...prev, achievements: newAchievements.length ? newAchievements : [''] };
    });
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validation
    if (!formData.company || !formData.position || !formData.startDate) {
      alert('Please fill in all required fields');
      return;
    }
    
    // Filter out empty achievements
    const filteredData = {
      ...formData,
      achievements: formData.achievements.filter(achievement => achievement.trim() !== '')
    };
    
    if (isEditing) {
      updateExperience(isEditing, filteredData);
      setIsEditing(null);
    } else {
      addExperience(filteredData);
      setIsAdding(false);
    }
    
    resetForm();
  };
  
  const handleEdit = (id: string) => {
    const experience = experiences.find(exp => exp.id === id);
    if (experience) {
      setFormData({
        company: experience.company,
        position: experience.position,
        location: experience.location,
        startDate: experience.startDate,
        endDate: experience.endDate,
        current: experience.current,
        description: experience.description,
        achievements: experience.achievements.length ? experience.achievements : ['']
      });
      setIsEditing(id);
      setIsAdding(true);
    }
  };
  
  const handleCancel = () => {
    setIsAdding(false);
    setIsEditing(null);
    resetForm();
  };
  
  const generateDescription = async () => {
    if (!formData.position || !formData.company) {
      alert('Please enter a position and company first');
      return;
    }
    
    setIsGeneratingDescription(true);
    
    try {
      const context = `${formData.position} at ${formData.company}`;
      const response = await generateAIContent({
        type: 'experience',
        context,
        jobTitle: formData.position
      });
      
      setFormData(prev => ({ ...prev, description: response.content }));
      setAiSuggestions(response.alternatives || []);
    } catch (error) {
      console.error('Error generating description:', error);
    } finally {
      setIsGeneratingDescription(false);
    }
  };
  
  const generateAchievement = async (index: number) => {
    if (!formData.position || !formData.company) {
      alert('Please enter a position and company first');
      return;
    }
    
    setIsGeneratingAchievement(true);
    
    try {
      const context = `${formData.position} at ${formData.company}`;
      const response = await generateAIContent({
        type: 'achievement',
        context,
        jobTitle: formData.position
      });
      
      handleAchievementChange(index, response.content);
    } catch (error) {
      console.error('Error generating achievement:', error);
    } finally {
      setIsGeneratingAchievement(false);
    }
  };
  
  const applySuggestion = (suggestion: string) => {
    setFormData(prev => ({ ...prev, description: suggestion }));
  };
  
  return (
    <div className="animate-fade-in space-y-6">
      <div className="card p-6">
        <div className="flex justify-between items-center mb-4">
          <h3 className="section-title">Work Experience</h3>
          
          {!isAdding && (
            <button
              type="button"
              onClick={() => setIsAdding(true)}
              className="btn btn-primary inline-flex items-center"
            >
              <Plus className="h-4 w-4 mr-1" />
              Add Experience
            </button>
          )}
        </div>
        
        {isAdding ? (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="form-group">
                <label htmlFor="company" className="form-label">Company Name *</label>
                <input
                  type="text"
                  id="company"
                  name="company"
                  value={formData.company}
                  onChange={handleInputChange}
                  className="input"
                  placeholder="Google"
                  required
                />
              </div>
              
              <div className="form-group">
                <label htmlFor="position" className="form-label">Position *</label>
                <input
                  type="text"
                  id="position"
                  name="position"
                  value={formData.position}
                  onChange={handleInputChange}
                  className="input"
                  placeholder="Senior Software Engineer"
                  required
                />
              </div>
              
              <div className="form-group">
                <label htmlFor="location" className="form-label">Location</label>
                <input
                  type="text"
                  id="location"
                  name="location"
                  value={formData.location}
                  onChange={handleInputChange}
                  className="input"
                  placeholder="Mountain View, CA"
                />
              </div>
              
              <div className="form-group">
                <label htmlFor="startDate" className="form-label">Start Date *</label>
                <input
                  type="month"
                  id="startDate"
                  name="startDate"
                  value={formData.startDate}
                  onChange={handleInputChange}
                  className="input"
                  required
                />
              </div>
              
              <div className="form-group">
                <div className="flex items-center mb-2">
                  <input
                    type="checkbox"
                    id="current"
                    name="current"
                    checked={formData.current}
                    onChange={handleCheckboxChange}
                    className="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300 rounded"
                  />
                  <label htmlFor="current" className="ml-2 block text-sm text-gray-700">
                    I currently work here
                  </label>
                </div>
                
                {!formData.current && (
                  <>
                    <label htmlFor="endDate" className="form-label">End Date</label>
                    <input
                      type="month"
                      id="endDate"
                      name="endDate"
                      value={formData.endDate}
                      onChange={handleInputChange}
                      className="input"
                    />
                  </>
                )}
              </div>
            </div>
            
            <div className="form-group">
              <label htmlFor="description" className="form-label flex items-center">
                Job Description
                <button
                  type="button"
                  onClick={generateDescription}
                  disabled={isGeneratingDescription}
                  className="ml-2 inline-flex items-center px-2 py-1 text-xs font-medium rounded bg-accent-100 text-accent-700 hover:bg-accent-200 transition-colors"
                >
                  {isGeneratingDescription ? (
                    <>Generating...</>
                  ) : (
                    <>
                      <Sparkles className="h-3 w-3 mr-1" />
                      Generate with AI
                    </>
                  )}
                </button>
              </label>
              <textarea
                id="description"
                name="description"
                value={formData.description}
                onChange={handleInputChange}
                className="textarea h-24"
                placeholder="Describe your responsibilities and role at the company"
              />
              <p className="form-helper">Focus on your responsibilities and the value you brought to the company</p>
            </div>
            
            {aiSuggestions.length > 0 && (
              <div className="bg-gray-50 p-4 rounded-md border border-gray-200">
                <h4 className="text-sm font-medium text-gray-900 mb-2 flex items-center">
                  <MessageSquare className="h-4 w-4 mr-1 text-accent-600" />
                  AI Suggestions
                </h4>
                <div className="space-y-2">
                  {aiSuggestions.map((suggestion, index) => (
                    <div key={index} className="bg-white p-3 rounded border border-gray-200 text-sm">
                      {suggestion}
                      <div className="mt-2">
                        <button
                          type="button"
                          onClick={() => applySuggestion(suggestion)}
                          className="text-xs font-medium text-accent-600 hover:text-accent-800"
                        >
                          Apply this suggestion
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
            
            <div className="form-group">
              <label className="form-label">Key Achievements</label>
              <p className="form-helper mb-2">
                Add bullet points highlighting your key accomplishments (quantify results when possible)
              </p>
              
              {formData.achievements.map((achievement, index) => (
                <div key={index} className="flex items-start mb-2">
                  <div className="flex-grow mr-2">
                    <div className="flex">
                      <input
                        type="text"
                        value={achievement}
                        onChange={(e) => handleAchievementChange(index, e.target.value)}
                        className="input"
                        placeholder="Increased revenue by 20% through implementation of new marketing strategy"
                      />
                      <button
                        type="button"
                        onClick={() => generateAchievement(index)}
                        disabled={isGeneratingAchievement}
                        className="ml-2 btn btn-outline inline-flex items-center"
                      >
                        <Sparkles className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => removeAchievementField(index)}
                    className="p-2 text-gray-400 hover:text-error-500"
                    aria-label="Remove achievement"
                  >
                    <Trash className="h-4 w-4" />
                  </button>
                </div>
              ))}
              
              <button
                type="button"
                onClick={addAchievementField}
                className="mt-2 inline-flex items-center text-sm text-primary-600 hover:text-primary-800"
              >
                <Plus className="h-4 w-4 mr-1" />
                Add Another Achievement
              </button>
            </div>
            
            <div className="flex justify-end space-x-2">
              <button
                type="button"
                onClick={handleCancel}
                className="btn btn-outline"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="btn btn-primary"
              >
                {isEditing ? 'Update' : 'Save'} Experience
              </button>
            </div>
          </form>
        ) : (
          <div className="space-y-4">
            {experiences.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-gray-500">No work experience added yet</p>
                <button
                  type="button"
                  onClick={() => setIsAdding(true)}
                  className="mt-2 btn btn-outline"
                >
                  Add Your First Experience
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                {experiences.map((experience) => (
                  <div key={experience.id} className="bg-gray-50 p-4 rounded-md border border-gray-200">
                    <div className="flex justify-between">
                      <div>
                        <h4 className="font-semibold text-gray-900">{experience.position}</h4>
                        <p className="text-gray-600">{experience.company}, {experience.location}</p>
                        <p className="text-sm text-gray-500">
                          {experience.startDate} - {experience.current ? 'Present' : experience.endDate}
                        </p>
                      </div>
                      <div className="flex space-x-2">
                        <button
                          type="button"
                          onClick={() => handleEdit(experience.id)}
                          className="p-2 text-gray-400 hover:text-primary-600"
                          aria-label="Edit experience"
                        >
                          <Edit className="h-4 w-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => removeExperience(experience.id)}
                          className="p-2 text-gray-400 hover:text-error-500"
                          aria-label="Remove experience"
                        >
                          <Trash className="h-4 w-4" />
                        </button>
                      </div>
                    </div>
                    
                    {experience.description && (
                      <p className="mt-2 text-sm text-gray-600">{experience.description}</p>
                    )}
                    
                    {experience.achievements.length > 0 && (
                      <div className="mt-2">
                        <p className="text-xs font-medium text-gray-700">Key Achievements:</p>
                        <ul className="mt-1 text-sm text-gray-600 list-disc list-inside">
                          {experience.achievements.map((achievement, idx) => (
                            <li key={idx}>{achievement}</li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default ExperienceForm;