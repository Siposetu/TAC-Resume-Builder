import React, { useState } from 'react';
import { useResume } from '../../context/ResumeContext';
import { generateAIContent } from '../../utils/mockAI';
import { Skill } from '../../types';
import { Plus, Trash, Edit, Sparkles, MessageSquare } from 'lucide-react';

const SkillsForm: React.FC = () => {
  const { resumeData, addSkillCategory, updateSkillCategory, removeSkillCategory, addSkill, updateSkill, removeSkill } = useResume();
  const { skillCategories, personalInfo, experiences } = resumeData;
  
  const [isAddingCategory, setIsAddingCategory] = useState(false);
  const [isEditingCategory, setIsEditingCategory] = useState<string | null>(null);
  const [categoryName, setCategoryName] = useState('');
  
  const [isAddingSkill, setIsAddingSkill] = useState<string | null>(null);
  const [skillData, setSkillData] = useState<Omit<Skill, 'id'>>({
    name: '',
    level: 3
  });
  
  const [isGeneratingSkills, setIsGeneratingSkills] = useState(false);
  const [aiSuggestions, setAiSuggestions] = useState<string[]>([]);
  
  const resetCategoryForm = () => {
    setCategoryName('');
    setIsEditingCategory(null);
  };
  
  const resetSkillForm = () => {
    setSkillData({
      name: '',
      level: 3
    });
  };
  
  const handleCategorySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!categoryName.trim()) {
      alert('Please enter a category name');
      return;
    }
    
    if (isEditingCategory) {
      updateSkillCategory(isEditingCategory, { name: categoryName });
      setIsEditingCategory(null);
    } else {
      addSkillCategory({ name: categoryName });
      setIsAddingCategory(false);
    }
    
    resetCategoryForm();
  };
  
  const handleSkillSubmit = (e: React.FormEvent, categoryId: string) => {
    e.preventDefault();
    
    if (!skillData.name.trim()) {
      alert('Please enter a skill name');
      return;
    }
    
    addSkill(categoryId, skillData);
    setIsAddingSkill(null);
    resetSkillForm();
  };
  
  const handleEditCategory = (id: string) => {
    const category = skillCategories.find(cat => cat.id === id);
    if (category) {
      setCategoryName(category.name);
      setIsEditingCategory(id);
      setIsAddingCategory(true);
    }
  };
  
  const handleCancelCategory = () => {
    setIsAddingCategory(false);
    resetCategoryForm();
  };
  
  const handleCancelSkill = () => {
    setIsAddingSkill(null);
    resetSkillForm();
  };
  
  const generateSkills = async (categoryId: string) => {
    setIsGeneratingSkills(true);
    
    try {
      // Create context from personal info and experiences
      const context = `
        ${personalInfo.title || 'Professional'} 
        ${experiences.map(exp => exp.position).join(' ')}
        ${experiences.map(exp => exp.description).join(' ')}
      `;
      
      const response = await generateAIContent({
        type: 'skill',
        context,
        jobTitle: personalInfo.title,
        industry: experiences[0]?.company || 'technology'
      });
      
      // Parse the comma-separated skills
      const skills = response.content.split(',').map(skill => skill.trim());
      
      // Add each skill to the category
      skills.forEach(skillName => {
        if (skillName) {
          addSkill(categoryId, {
            name: skillName,
            level: Math.floor(Math.random() * 3) + 3 // Random level between 3-5
          });
        }
      });
      
      // Store alternatives for manual selection
      setAiSuggestions(
        response.alternatives
          ? response.alternatives.flatMap(alt => alt.split(',').map(skill => skill.trim()))
          : []
      );
    } catch (error) {
      console.error('Error generating skills:', error);
    } finally {
      setIsGeneratingSkills(false);
    }
  };
  
  const addSuggestedSkill = (skillName: string, categoryId: string) => {
    addSkill(categoryId, {
      name: skillName,
      level: Math.floor(Math.random() * 3) + 3 // Random level between 3-5
    });
    
    // Remove from suggestions
    setAiSuggestions(prev => prev.filter(skill => skill !== skillName));
  };
  
  return (
    <div className="animate-fade-in space-y-6">
      <div className="card p-6">
        <div className="flex justify-between items-center mb-4">
          <h3 className="section-title">Skills</h3>
          
          {!isAddingCategory && (
            <button
              type="button"
              onClick={() => setIsAddingCategory(true)}
              className="btn btn-primary inline-flex items-center"
            >
              <Plus className="h-4 w-4 mr-1" />
              Add Skill Category
            </button>
          )}
        </div>
        
        {isAddingCategory ? (
          <form onSubmit={handleCategorySubmit} className="space-y-4">
            <div className="form-group">
              <label htmlFor="categoryName" className="form-label">Category Name</label>
              <input
                type="text"
                id="categoryName"
                value={categoryName}
                onChange={(e) => setCategoryName(e.target.value)}
                className="input"
                placeholder="Technical Skills, Soft Skills, Languages, etc."
                required
              />
            </div>
            
            <div className="flex justify-end space-x-2">
              <button
                type="button"
                onClick={handleCancelCategory}
                className="btn btn-outline"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="btn btn-primary"
              >
                {isEditingCategory ? 'Update' : 'Add'} Category
              </button>
            </div>
          </form>
        ) : (
          <div className="space-y-6">
            {skillCategories.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-gray-500">No skill categories added yet</p>
                <button
                  type="button"
                  onClick={() => setIsAddingCategory(true)}
                  className="mt-2 btn btn-outline"
                >
                  Add Your First Skill Category
                </button>
              </div>
            ) : (
              skillCategories.map((category) => (
                <div key={category.id} className="bg-gray-50 p-4 rounded-md border border-gray-200">
                  <div className="flex justify-between items-center mb-3">
                    <h4 className="font-semibold text-gray-900">{category.name}</h4>
                    <div className="flex space-x-2">
                      <button
                        type="button"
                        onClick={() => handleEditCategory(category.id)}
                        className="p-1 text-gray-400 hover:text-primary-600"
                        aria-label="Edit category"
                      >
                        <Edit className="h-4 w-4" />
                      </button>
                      <button
                        type="button"
                        onClick={() => removeSkillCategory(category.id)}
                        className="p-1 text-gray-400 hover:text-error-500"
                        aria-label="Remove category"
                      >
                        <Trash className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                  
                  {/* Skills List */}
                  <div className="space-y-2">
                    {category.skills.map((skill) => (
                      <div key={skill.id} className="flex items-center justify-between bg-white p-2 rounded border border-gray-200">
                        <div className="flex-grow">
                          <div className="flex justify-between">
                            <span className="text-gray-800">{skill.name}</span>
                            <div className="flex items-center">
                              {[1, 2, 3, 4, 5].map((level) => (
                                <div 
                                  key={level}
                                  className={`h-2 w-6 mx-0.5 rounded-sm ${
                                    level <= skill.level ? 'bg-primary-500' : 'bg-gray-200'
                                  }`}
                                />
                              ))}
                            </div>
                          </div>
                        </div>
                        <button
                          type="button"
                          onClick={() => removeSkill(category.id, skill.id)}
                          className="ml-2 p-1 text-gray-400 hover:text-error-500"
                          aria-label="Remove skill"
                        >
                          <Trash className="h-3 w-3" />
                        </button>
                      </div>
                    ))}
                  </div>
                  
                  {/* Add Skill Form */}
                  {isAddingSkill === category.id ? (
                    <form onSubmit={(e) => handleSkillSubmit(e, category.id)} className="mt-3 space-y-3">
                      <div className="form-group">
                        <label htmlFor="skillName" className="form-label">Skill Name</label>
                        <input
                          type="text"
                          id="skillName"
                          value={skillData.name}
                          onChange={(e) => setSkillData(prev => ({ ...prev, name: e.target.value }))}
                          className="input"
                          placeholder="JavaScript, Project Management, etc."
                          required
                        />
                      </div>
                      
                      <div className="form-group">
                        <label htmlFor="skillLevel" className="form-label">Proficiency Level: {skillData.level}/5</label>
                        <input
                          type="range"
                          id="skillLevel"
                          min="1"
                          max="5"
                          value={skillData.level}
                          onChange={(e) => setSkillData(prev => ({ ...prev, level: parseInt(e.target.value) }))}
                          className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                        />
                        <div className="flex justify-between text-xs text-gray-500 mt-1">
                          <span>Beginner</span>
                          <span>Intermediate</span>
                          <span>Expert</span>
                        </div>
                      </div>
                      
                      <div className="flex justify-end space-x-2">
                        <button
                          type="button"
                          onClick={handleCancelSkill}
                          className="btn btn-outline"
                        >
                          Cancel
                        </button>
                        <button
                          type="submit"
                          className="btn btn-primary"
                        >
                          Add Skill
                        </button>
                      </div>
                    </form>
                  ) : (
                    <div className="mt-3 flex flex-wrap items-center gap-2">
                      <button
                        type="button"
                        onClick={() => setIsAddingSkill(category.id)}
                        className="inline-flex items-center text-sm text-primary-600 hover:text-primary-800"
                      >
                        <Plus className="h-4 w-4 mr-1" />
                        Add Skill
                      </button>
                      
                      <button
                        type="button"
                        onClick={() => generateSkills(category.id)}
                        disabled={isGeneratingSkills}
                        className="inline-flex items-center text-sm text-accent-600 hover:text-accent-800"
                      >
                        <Sparkles className="h-4 w-4 mr-1" />
                        {isGeneratingSkills ? 'Generating...' : 'Generate Skills with AI'}
                      </button>
                    </div>
                  )}
                  
                  {/* AI Skill Suggestions */}
                  {aiSuggestions.length > 0 && (
                    <div className="mt-4 bg-white p-3 rounded border border-gray-200">
                      <h5 className="text-sm font-medium text-gray-900 mb-2 flex items-center">
                        <MessageSquare className="h-4 w-4 mr-1 text-accent-600" />
                        AI Suggested Skills
                      </h5>
                      <div className="flex flex-wrap gap-2">
                        {aiSuggestions.map((skill, index) => (
                          <button
                            key={index}
                            type="button"
                            onClick={() => addSuggestedSkill(skill, category.id)}
                            className="inline-flex items-center px-2 py-1 text-xs rounded-full bg-accent-50 text-accent-700 hover:bg-accent-100"
                          >
                            <Plus className="h-3 w-3 mr-1" />
                            {skill}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default SkillsForm;