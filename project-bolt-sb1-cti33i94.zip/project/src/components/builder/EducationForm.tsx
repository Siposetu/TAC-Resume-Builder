import React, { useState } from 'react';
import { useResume } from '../../context/ResumeContext';
import { Education } from '../../types';
import { Plus, Trash, Edit } from 'lucide-react';

const EducationForm: React.FC = () => {
  const { resumeData, addEducation, updateEducation, removeEducation } = useResume();
  const { educations } = resumeData;
  
  const [isAdding, setIsAdding] = useState(false);
  const [isEditing, setIsEditing] = useState<string | null>(null);
  
  const [formData, setFormData] = useState<Omit<Education, 'id'>>({
    institution: '',
    degree: '',
    fieldOfStudy: '',
    location: '',
    startDate: '',
    endDate: '',
    current: false,
    description: '',
    achievements: ['']
  });
  
  const resetForm = () => {
    setFormData({
      institution: '',
      degree: '',
      fieldOfStudy: '',
      location: '',
      startDate: '',
      endDate: '',
      current: false,
      description: '',
      achievements: ['']
    });
  };
  
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  const handleCheckboxChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, checked } = e.target;
    setFormData(prev => ({ ...prev, [name]: checked }));
  };
  
  const handleAchievementChange = (index: number, value: string) => {
    setFormData(prev => {
      const newAchievements = [...prev.achievements];
      newAchievements[index] = value;
      return { ...prev, achievements: newAchievements };
    });
  };
  
  const addAchievementField = () => {
    setFormData(prev => ({
      ...prev,
      achievements: [...prev.achievements, '']
    }));
  };
  
  const removeAchievementField = (index: number) => {
    setFormData(prev => {
      const newAchievements = [...prev.achievements];
      newAchievements.splice(index, 1);
      return { ...prev, achievements: newAchievements.length ? newAchievements : [''] };
    });
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validation
    if (!formData.institution || !formData.degree || !formData.startDate) {
      alert('Please fill in all required fields');
      return;
    }
    
    // Filter out empty achievements
    const filteredData = {
      ...formData,
      achievements: formData.achievements.filter(achievement => achievement.trim() !== '')
    };
    
    if (isEditing) {
      updateEducation(isEditing, filteredData);
      setIsEditing(null);
    } else {
      addEducation(filteredData);
      setIsAdding(false);
    }
    
    resetForm();
  };
  
  const handleEdit = (id: string) => {
    const education = educations.find(edu => edu.id === id);
    if (education) {
      setFormData({
        institution: education.institution,
        degree: education.degree,
        fieldOfStudy: education.fieldOfStudy,
        location: education.location,
        startDate: education.startDate,
        endDate: education.endDate,
        current: education.current,
        description: education.description,
        achievements: education.achievements.length ? education.achievements : ['']
      });
      setIsEditing(id);
      setIsAdding(true);
    }
  };
  
  const handleCancel = () => {
    setIsAdding(false);
    setIsEditing(null);
    resetForm();
  };
  
  return (
    <div className="animate-fade-in space-y-6">
      <div className="card p-6">
        <div className="flex justify-between items-center mb-4">
          <h3 className="section-title">Education</h3>
          
          {!isAdding && (
            <button
              type="button"
              onClick={() => setIsAdding(true)}
              className="btn btn-primary inline-flex items-center"
            >
              <Plus className="h-4 w-4 mr-1" />
              Add Education
            </button>
          )}
        </div>
        
        {isAdding ? (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="form-group">
                <label htmlFor="institution" className="form-label">Institution Name *</label>
                <input
                  type="text"
                  id="institution"
                  name="institution"
                  value={formData.institution}
                  onChange={handleInputChange}
                  className="input"
                  placeholder="Stanford University"
                  required
                />
              </div>
              
              <div className="form-group">
                <label htmlFor="location" className="form-label">Location</label>
                <input
                  type="text"
                  id="location"
                  name="location"
                  value={formData.location}
                  onChange={handleInputChange}
                  className="input"
                  placeholder="Stanford, CA"
                />
              </div>
              
              <div className="form-group">
                <label htmlFor="degree" className="form-label">Degree *</label>
                <input
                  type="text"
                  id="degree"
                  name="degree"
                  value={formData.degree}
                  onChange={handleInputChange}
                  className="input"
                  placeholder="Bachelor of Science"
                  required
                />
              </div>
              
              <div className="form-group">
                <label htmlFor="fieldOfStudy" className="form-label">Field of Study</label>
                <input
                  type="text"
                  id="fieldOfStudy"
                  name="fieldOfStudy"
                  value={formData.fieldOfStudy}
                  onChange={handleInputChange}
                  className="input"
                  placeholder="Computer Science"
                />
              </div>
              
              <div className="form-group">
                <label htmlFor="startDate" className="form-label">Start Date *</label>
                <input
                  type="month"
                  id="startDate"
                  name="startDate"
                  value={formData.startDate}
                  onChange={handleInputChange}
                  className="input"
                  required
                />
              </div>
              
              <div className="form-group">
                <div className="flex items-center mb-2">
                  <input
                    type="checkbox"
                    id="current"
                    name="current"
                    checked={formData.current}
                    onChange={handleCheckboxChange}
                    className="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300 rounded"
                  />
                  <label htmlFor="current" className="ml-2 block text-sm text-gray-700">
                    I'm currently studying here
                  </label>
                </div>
                
                {!formData.current && (
                  <>
                    <label htmlFor="endDate" className="form-label">End Date</label>
                    <input
                      type="month"
                      id="endDate"
                      name="endDate"
                      value={formData.endDate}
                      onChange={handleInputChange}
                      className="input"
                    />
                  </>
                )}
              </div>
            </div>
            
            <div className="form-group">
              <label htmlFor="description" className="form-label">Description</label>
              <textarea
                id="description"
                name="description"
                value={formData.description}
                onChange={handleInputChange}
                className="textarea h-24"
                placeholder="Describe your area of study, relevant coursework, or any other details about your education"
              />
            </div>
            
            <div className="form-group">
              <label className="form-label">Achievements/Activities</label>
              <p className="form-helper mb-2">
                Add notable achievements, awards, activities, or relevant coursework
              </p>
              
              {formData.achievements.map((achievement, index) => (
                <div key={index} className="flex items-start mb-2">
                  <div className="flex-grow mr-2">
                    <input
                      type="text"
                      value={achievement}
                      onChange={(e) => handleAchievementChange(index, e.target.value)}
                      className="input"
                      placeholder="Dean's List (All Semesters), Senior Thesis: Machine Learning Applications"
                    />
                  </div>
                  <button
                    type="button"
                    onClick={() => removeAchievementField(index)}
                    className="p-2 text-gray-400 hover:text-error-500"
                    aria-label="Remove achievement"
                  >
                    <Trash className="h-4 w-4" />
                  </button>
                </div>
              ))}
              
              <button
                type="button"
                onClick={addAchievementField}
                className="mt-2 inline-flex items-center text-sm text-primary-600 hover:text-primary-800"
              >
                <Plus className="h-4 w-4 mr-1" />
                Add Another Achievement
              </button>
            </div>
            
            <div className="flex justify-end space-x-2">
              <button
                type="button"
                onClick={handleCancel}
                className="btn btn-outline"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="btn btn-primary"
              >
                {isEditing ? 'Update' : 'Save'} Education
              </button>
            </div>
          </form>
        ) : (
          <div className="space-y-4">
            {educations.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-gray-500">No education added yet</p>
                <button
                  type="button"
                  onClick={() => setIsAdding(true)}
                  className="mt-2 btn btn-outline"
                >
                  Add Your Education
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                {educations.map((education) => (
                  <div key={education.id} className="bg-gray-50 p-4 rounded-md border border-gray-200">
                    <div className="flex justify-between">
                      <div>
                        <h4 className="font-semibold text-gray-900">{education.degree}{education.fieldOfStudy ? ` in ${education.fieldOfStudy}` : ''}</h4>
                        <p className="text-gray-600">{education.institution}, {education.location}</p>
                        <p className="text-sm text-gray-500">
                          {education.startDate} - {education.current ? 'Present' : education.endDate}
                        </p>
                      </div>
                      <div className="flex space-x-2">
                        <button
                          type="button"
                          onClick={() => handleEdit(education.id)}
                          className="p-2 text-gray-400 hover:text-primary-600"
                          aria-label="Edit education"
                        >
                          <Edit className="h-4 w-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => removeEducation(education.id)}
                          className="p-2 text-gray-400 hover:text-error-500"
                          aria-label="Remove education"
                        >
                          <Trash className="h-4 w-4" />
                        </button>
                      </div>
                    </div>
                    
                    {education.description && (
                      <p className="mt-2 text-sm text-gray-600">{education.description}</p>
                    )}
                    
                    {education.achievements.length > 0 && (
                      <div className="mt-2">
                        <p className="text-xs font-medium text-gray-700">Achievements/Activities:</p>
                        <ul className="mt-1 text-sm text-gray-600 list-disc list-inside">
                          {education.achievements.map((achievement, idx) => (
                            <li key={idx}>{achievement}</li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default EducationForm;