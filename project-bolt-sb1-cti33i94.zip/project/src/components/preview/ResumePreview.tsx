import React, { useRef, useState } from 'react';
import { useResume } from '../../context/ResumeContext';
import { exportToPDF, exportToDOCX, exportToHTML } from '../../utils/export';
import { saveAsNewResume } from '../../utils/storage';
import ModernTemplate from '../resume/ModernTemplate';
import ProfessionalTemplate from '../resume/ProfessionalTemplate';
import CreativeTemplate from '../resume/CreativeTemplate';
import { Download, FileText, Code, RefreshCw, Palette, Save } from 'lucide-react';
import { ColorScheme, TemplateType } from '../../types';

const ResumePreview: React.FC = () => {
  const { resumeData, updateTemplate, updateColor } = useResume();
  const resumeRef = useRef<HTMLDivElement>(null);
  const [exportLoading, setExportLoading] = useState({
    pdf: false,
    docx: false,
    html: false
  });
  const [showSaveDialog, setShowSaveDialog] = useState(false);
  const [resumeName, setResumeName] = useState('');
  
  const handleExportPDF = async () => {
    setExportLoading(prev => ({ ...prev, pdf: true }));
    try {
      await exportToPDF(resumeRef, resumeData);
    } catch (error) {
      console.error('Error exporting to PDF:', error);
      alert('Failed to export PDF. Please try again.');
    } finally {
      setExportLoading(prev => ({ ...prev, pdf: false }));
    }
  };
  
  const handleExportDOCX = async () => {
    setExportLoading(prev => ({ ...prev, docx: true }));
    try {
      await exportToDOCX(resumeData);
    } catch (error) {
      console.error('Error exporting to DOCX:', error);
      alert('Failed to export DOCX. Please try again.');
    } finally {
      setExportLoading(prev => ({ ...prev, docx: false }));
    }
  };
  
  const handleExportHTML = () => {
    setExportLoading(prev => ({ ...prev, html: true }));
    try {
      exportToHTML(resumeRef, resumeData);
    } catch (error) {
      console.error('Error exporting to HTML:', error);
      alert('Failed to export HTML. Please try again.');
    } finally {
      setExportLoading(prev => ({ ...prev, html: false }));
    }
  };
  
  const handleTemplateChange = (template: TemplateType) => {
    updateTemplate(template);
  };
  
  const handleColorChange = (color: ColorScheme) => {
    updateColor(color);
  };

  const handleSaveResume = () => {
    if (!resumeName.trim()) {
      alert('Please enter a name for your resume');
      return;
    }
    saveAsNewResume(resumeData, resumeName);
    setShowSaveDialog(false);
    setResumeName('');
    alert('Resume saved successfully!');
  };
  
  const renderTemplate = () => {
    switch (resumeData.template) {
      case 'modern':
        return <ModernTemplate resumeData={resumeData} />;
      case 'professional':
        return <ProfessionalTemplate resumeData={resumeData} />;
      case 'creative':
        return <CreativeTemplate resumeData={resumeData} />;
      default:
        return <ModernTemplate resumeData={resumeData} />;
    }
  };
  
  return (
    <div className="py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white shadow rounded-lg overflow-hidden">
          <div className="p-6 border-b border-gray-200">
            <h2 className="text-xl font-semibold text-gray-900">Resume Preview</h2>
            <p className="mt-1 text-sm text-gray-600">
              Review your resume and export it in your preferred format
            </p>
          </div>
          
          <div className="p-6 bg-gray-50 border-b border-gray-200">
            <div className="flex flex-wrap gap-4">
              <div>
                <h3 className="text-sm font-medium text-gray-700 mb-2">Template Style</h3>
                <div className="flex space-x-2">
                  <button
                    type="button"
                    onClick={() => handleTemplateChange('modern')}
                    className={`px-4 py-2 text-sm font-medium rounded-md ${
                      resumeData.template === 'modern'
                        ? 'bg-primary-600 text-white'
                        : 'bg-white text-gray-700 border border-gray-300 hover:bg-gray-50'
                    }`}
                  >
                    Modern
                  </button>
                  <button
                    type="button"
                    onClick={() => handleTemplateChange('professional')}
                    className={`px-4 py-2 text-sm font-medium rounded-md ${
                      resumeData.template === 'professional'
                        ? 'bg-primary-600 text-white'
                        : 'bg-white text-gray-700 border border-gray-300 hover:bg-gray-50'
                    }`}
                  >
                    Professional
                  </button>
                  <button
                    type="button"
                    onClick={() => handleTemplateChange('creative')}
                    className={`px-4 py-2 text-sm font-medium rounded-md ${
                      resumeData.template === 'creative'
                        ? 'bg-primary-600 text-white'
                        : 'bg-white text-gray-700 border border-gray-300 hover:bg-gray-50'
                    }`}
                  >
                    Creative
                  </button>
                </div>
              </div>
              
              <div>
                <h3 className="text-sm font-medium text-gray-700 mb-2">Color Scheme</h3>
                <div className="flex space-x-2">
                  <button
                    type="button"
                    onClick={() => handleColorChange('blue')}
                    className={`w-8 h-8 rounded-full bg-primary-600 ${
                      resumeData.color === 'blue' ? 'ring-2 ring-offset-2 ring-primary-500' : ''
                    }`}
                    aria-label="Blue color scheme"
                  />
                  <button
                    type="button"
                    onClick={() => handleColorChange('teal')}
                    className={`w-8 h-8 rounded-full bg-secondary-600 ${
                      resumeData.color === 'teal' ? 'ring-2 ring-offset-2 ring-secondary-500' : ''
                    }`}
                    aria-label="Teal color scheme"
                  />
                  <button
                    type="button"
                    onClick={() => handleColorChange('purple')}
                    className={`w-8 h-8 rounded-full bg-accent-600 ${
                      resumeData.color === 'purple' ? 'ring-2 ring-offset-2 ring-accent-500' : ''
                    }`}
                    aria-label="Purple color scheme"
                  />
                  <button
                    type="button"
                    onClick={() => handleColorChange('gray')}
                    className={`w-8 h-8 rounded-full bg-gray-600 ${
                      resumeData.color === 'gray' ? 'ring-2 ring-offset-2 ring-gray-500' : ''
                    }`}
                    aria-label="Gray color scheme"
                  />
                  <button
                    type="button"
                    onClick={() => handleColorChange('green')}
                    className={`w-8 h-8 rounded-full bg-success-600 ${
                      resumeData.color === 'green' ? 'ring-2 ring-offset-2 ring-success-500' : ''
                    }`}
                    aria-label="Green color scheme"
                  />
                  <button
                    type="button"
                    onClick={() => handleColorChange('red')}
                    className={`w-8 h-8 rounded-full bg-error-600 ${
                      resumeData.color === 'red' ? 'ring-2 ring-offset-2 ring-error-500' : ''
                    }`}
                    aria-label="Red color scheme"
                  />
                </div>
              </div>
            </div>
          </div>
          
          <div className="p-6 border-b border-gray-200 flex justify-between">
            <div className="text-sm text-gray-700">
              <span className="font-medium">Tip:</span> Make sure all sections are complete for the best-looking resume.
            </div>
            
            <div className="flex space-x-2">
              <button
                type="button"
                onClick={() => setShowSaveDialog(true)}
                className="btn btn-outline inline-flex items-center"
              >
                <Save className="h-4 w-4 mr-1.5" />
                Save Resume
              </button>

              <button
                type="button"
                onClick={handleExportPDF}
                disabled={exportLoading.pdf}
                className="btn btn-outline inline-flex items-center"
              >
                {exportLoading.pdf ? (
                  <RefreshCw className="animate-spin h-4 w-4 mr-1.5" />
                ) : (
                  <Download className="h-4 w-4 mr-1.5" />
                )}
                Export PDF
              </button>
              
              <button
                type="button"
                onClick={handleExportDOCX}
                disabled={exportLoading.docx}
                className="btn btn-outline inline-flex items-center"
              >
                {exportLoading.docx ? (
                  <RefreshCw className="animate-spin h-4 w-4 mr-1.5" />
                ) : (
                  <FileText className="h-4 w-4 mr-1.5" />
                )}
                Export DOCX
              </button>
              
              <button
                type="button"
                onClick={handleExportHTML}
                disabled={exportLoading.html}
                className="btn btn-outline inline-flex items-center"
              >
                {exportLoading.html ? (
                  <RefreshCw className="animate-spin h-4 w-4 mr-1.5" />
                ) : (
                  <Code className="h-4 w-4 mr-1.5" />
                )}
                Export HTML
              </button>
            </div>
          </div>
          
          <div className="flex justify-center p-8 bg-gray-50">
            <div className="w-full max-w-[21cm] shadow-xl transition-all duration-300" ref={resumeRef}>
              {renderTemplate()}
            </div>
          </div>
        </div>
      </div>

      {/* Save Resume Dialog */}
      {showSaveDialog && (
        <div className="fixed inset-0 bg-gray-500 bg-opacity-75 flex items-center justify-center">
          <div className="bg-white rounded-lg p-6 max-w-md w-full">
            <h3 className="text-lg font-medium text-gray-900 mb-4">Save Resume</h3>
            <input
              type="text"
              value={resumeName}
              onChange={(e) => setResumeName(e.target.value)}
              placeholder="Enter resume name"
              className="input mb-4"
            />
            <div className="flex justify-end space-x-2">
              <button
                type="button"
                onClick={() => setShowSaveDialog(false)}
                className="btn btn-outline"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleSaveResume}
                className="btn btn-primary"
              >
                Save
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ResumePreview;