import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { FileText, Download, Home, Save } from 'lucide-react';

const Header: React.FC = () => {
  const location = useLocation();
  
  return (
    <header className="bg-white shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <Link to="/" className="flex items-center">
              <FileText className="h-8 w-8 text-primary-600" />
              <span className="ml-2 text-xl font-semibold text-gray-900">TAC Resume Builder</span>
            </Link>
          </div>
          
          <nav className="flex space-x-4">
            <Link
              to="/"
              className={`inline-flex items-center px-3 py-2 text-sm font-medium rounded-md ${
                location.pathname === '/' 
                  ? 'text-primary-700 bg-primary-50' 
                  : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'
              }`}
            >
              <Home className="mr-1.5 h-4 w-4" />
              Home
            </Link>
            
            <Link
              to="/builder"
              className={`inline-flex items-center px-3 py-2 text-sm font-medium rounded-md ${
                location.pathname === '/builder' 
                  ? 'text-primary-700 bg-primary-50' 
                  : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'
              }`}
            >
              <FileText className="mr-1.5 h-4 w-4" />
              Builder
            </Link>
            
            <Link
              to="/saved"
              className={`inline-flex items-center px-3 py-2 text-sm font-medium rounded-md ${
                location.pathname === '/saved' 
                  ? 'text-primary-700 bg-primary-50' 
                  : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'
              }`}
            >
              <Save className="mr-1.5 h-4 w-4" />
              Saved Resumes
            </Link>
            
            <Link
              to="/preview"
              className={`inline-flex items-center px-3 py-2 text-sm font-medium rounded-md ${
                location.pathname === '/preview' 
                  ? 'text-primary-700 bg-primary-50' 
                  : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'
              }`}
            >
              <Download className="mr-1.5 h-4 w-4" />
              Preview & Export
            </Link>
          </nav>
        </div>
      </div>
    </header>
  );
};

export default Header;