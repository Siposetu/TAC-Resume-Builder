import { AIGenerationRequest, AIGenerationResponse } from '../types';

// This is a mock implementation of AI content generation
export const generateAIContent = (request: AIGenerationRequest): Promise<AIGenerationResponse> => {
  // Simulate API delay
  return new Promise((resolve) => {
    setTimeout(() => {
      switch (request.type) {
        case 'summary':
          resolve(generateSummary(request));
          break;
        case 'experience':
          resolve(generateExperience(request));
          break;
        case 'achievement':
          resolve(generateAchievement(request));
          break;
        case 'skill':
          resolve(generateSkill(request));
          break;
        default:
          resolve({
            content: 'Unable to generate content for this type.',
            alternatives: [],
            suggestions: ['Try providing more context.'],
          });
      }
    }, 1000);
  });
};

const generateSummary = (request: AIGenerationRequest): AIGenerationResponse => {
  const { context, jobTitle = '', industry = 'technology' } = request;
  
  // Job-specific summary templates
  const summaryTemplates: Record<string, string> = {
    'software engineer': `Innovative Software Engineer with expertise in developing scalable applications and implementing cutting-edge solutions. Skilled in modern development practices and committed to writing clean, maintainable code. Experienced in agile environments and cross-functional collaboration.`,
    
    'product manager': `Strategic Product Manager with a track record of driving product vision and delivering customer-centric solutions. Experienced in market analysis, roadmap development, and cross-functional team leadership. Proven ability to balance business objectives with user needs.`,
    
    'data scientist': `Results-driven Data Scientist combining strong analytical skills with machine learning expertise. Experienced in developing predictive models and extracting actionable insights from complex datasets. Proven track record of driving data-informed decisions.`,
    
    'ux designer': `Creative UX Designer focused on crafting intuitive and engaging user experiences. Skilled in user research, wireframing, and prototyping. Passionate about creating accessible and user-centered design solutions that drive business growth.`,
    
    'marketing manager': `Dynamic Marketing Manager with expertise in developing and executing comprehensive marketing strategies. Skilled in digital marketing, brand development, and campaign optimization. Proven track record of driving growth and engagement.`,
  };

  // Find the most relevant template based on job title
  const matchingTitle = Object.keys(summaryTemplates).find(title => 
    jobTitle.toLowerCase().includes(title) || title.includes(jobTitle.toLowerCase())
  );

  const summary = matchingTitle 
    ? summaryTemplates[matchingTitle]
    : `Experienced ${jobTitle} professional with a proven track record in ${industry}. Combines technical expertise with strong problem-solving abilities to deliver exceptional results. Committed to continuous learning and professional growth.`;

  // Generate alternative summaries based on different aspects of the role
  const alternatives = [
    `Detail-oriented ${jobTitle} bringing extensive experience in ${industry}. Known for delivering high-quality solutions while maintaining strong collaboration with cross-functional teams.`,
    `Forward-thinking ${jobTitle} with a passion for innovation in ${industry}. Demonstrated success in implementing effective solutions that drive business growth and operational efficiency.`
  ];

  return {
    content: summary,
    alternatives,
    suggestions: [
      'Add specific achievements with measurable results',
      'Include relevant certifications or specialized training',
      'Mention key technologies or methodologies used',
      'Highlight industry-specific expertise'
    ]
  };
};

const generateExperience = (request: AIGenerationRequest): AIGenerationResponse => {
  const { jobTitle = '', context = '' } = request;
  
  // Job-specific experience templates
  const experienceTemplates: Record<string, string> = {
    'software engineer': `Led development of scalable microservices architecture, implementing best practices in code quality and testing. Collaborated with cross-functional teams to deliver robust solutions that improved system performance by 40%.`,
    
    'product manager': `Spearheaded product strategy and roadmap development, leading cross-functional teams through successful product launches. Conducted market research and user interviews to identify opportunities and define product requirements.`,
    
    'data scientist': `Developed and implemented machine learning models to optimize business processes and predict customer behavior. Created data pipelines and analytics dashboards that provided actionable insights to stakeholders.`,
    
    'ux designer': `Designed and implemented user-centered solutions through comprehensive research, wireframing, and prototyping. Conducted usability testing and iteratively improved designs based on user feedback.`,
    
    'marketing manager': `Developed and executed comprehensive marketing strategies across digital and traditional channels. Managed campaign budgets and analyzed performance metrics to optimize ROI.`
  };

  // Find the most relevant template based on job title
  const matchingTitle = Object.keys(experienceTemplates).find(title => 
    jobTitle.toLowerCase().includes(title) || title.includes(jobTitle.toLowerCase())
  );

  const experience = matchingTitle 
    ? experienceTemplates[matchingTitle]
    : `Led key initiatives and projects in ${jobTitle} role, delivering significant improvements in efficiency and quality. Collaborated with stakeholders to ensure successful implementation of solutions.`;

  const alternatives = [
    `Managed complex projects and initiatives, demonstrating strong leadership and problem-solving abilities. Consistently delivered results that exceeded expectations and contributed to business growth.`,
    `Drove innovation and process improvements while maintaining high standards of quality and efficiency. Built strong relationships with stakeholders and team members to ensure project success.`
  ];

  return {
    content: experience,
    alternatives,
    suggestions: [
      'Quantify achievements with specific metrics',
      'Highlight leadership and collaboration',
      'Include specific technologies or methodologies',
      'Mention impact on business objectives'
    ]
  };
};

const generateAchievement = (request: AIGenerationRequest): AIGenerationResponse => {
  const { jobTitle = '', context = '' } = request;
  
  // Job-specific achievement templates
  const achievementTemplates: Record<string, string[]> = {
    'software engineer': [
      'Reduced application load time by 45% through optimization of database queries and implementation of caching strategies',
      'Led migration to microservices architecture, improving system scalability and reducing deployment time by 60%',
      'Implemented automated testing pipeline that increased code coverage to 95% and reduced bug reports by 40%'
    ],
    
    'product manager': [
      'Launched new product feature that increased user engagement by 35% and generated $2M in additional revenue',
      'Led agile transformation that reduced time-to-market by 50% and improved team velocity by 40%',
      'Developed product strategy that resulted in 25% market share growth within 6 months'
    ],
    
    'data scientist': [
      'Developed predictive model that improved customer retention by 30% and generated $1.5M in saved revenue',
      'Created automated reporting system that reduced manual analysis time by 75%',
      'Implemented A/B testing framework that improved conversion rates by 25%'
    ],
    
    'ux designer': [
      'Redesigned core product interface, reducing user error rates by 40% and support tickets by 30%',
      'Implemented design system that reduced development time for new features by 50%',
      'Conducted user research that led to 45% improvement in task completion rates'
    ],
    
    'marketing manager': [
      'Launched digital campaign that generated 150% ROI and increased brand awareness by 40%',
      'Optimized marketing funnel resulting in 35% increase in conversion rates',
      'Developed content strategy that doubled organic traffic within 3 months'
    ]
  };

  // Find the most relevant template based on job title
  const matchingTitle = Object.keys(achievementTemplates).find(title => 
    jobTitle.toLowerCase().includes(title) || title.includes(jobTitle.toLowerCase())
  );

  const achievements = matchingTitle 
    ? achievementTemplates[matchingTitle]
    : [
        `Increased operational efficiency by 30% through implementation of new processes and tools`,
        `Led successful completion of key projects that delivered 25% cost savings`,
        `Developed innovative solutions that improved team productivity by 40%`
      ];

  return {
    content: achievements[Math.floor(Math.random() * achievements.length)],
    alternatives: achievements.slice(0, 2),
    suggestions: [
      'Include specific metrics and percentages',
      'Highlight impact on business goals',
      'Mention tools or methodologies used',
      'Focus on results and outcomes'
    ]
  };
};

const generateSkill = (request: AIGenerationRequest): AIGenerationResponse => {
  const { jobTitle = '', industry = 'technology' } = request;
  
  // Job-specific skill templates
  const skillTemplates: Record<string, string[]> = {
    'software engineer': [
      'JavaScript, TypeScript, React, Node.js, Python',
      'REST APIs, GraphQL, Microservices, Docker',
      'AWS, Azure, CI/CD, Git, Agile Development',
      'System Design, Database Optimization, Security',
      'Test-Driven Development, Code Review, DevOps'
    ],
    
    'product manager': [
      'Product Strategy, Roadmap Planning, Agile/Scrum',
      'Market Research, User Stories, Requirements Gathering',
      'Data Analysis, A/B Testing, Product Analytics',
      'Stakeholder Management, Cross-functional Leadership',
      'Product Launch, Go-to-Market Strategy, User Research'
    ],
    
    'data scientist': [
      'Python, R, SQL, Machine Learning, Deep Learning',
      'Statistical Analysis, Data Visualization, Big Data',
      'TensorFlow, PyTorch, Scikit-learn, Pandas',
      'A/B Testing, Hypothesis Testing, Regression Analysis',
      'Data Mining, Feature Engineering, Model Deployment'
    ],
    
    'ux designer': [
      'User Research, Wireframing, Prototyping',
      'Figma, Adobe XD, Sketch, InVision',
      'Information Architecture, User Flows, Journey Mapping',
      'Usability Testing, A/B Testing, Design Systems',
      'Accessibility, Responsive Design, Visual Design'
    ],
    
    'marketing manager': [
      'Digital Marketing, SEO, SEM, Social Media Marketing',
      'Content Strategy, Brand Development, Email Marketing',
      'Analytics, Campaign Management, Marketing Automation',
      'Budget Management, ROI Analysis, Market Research',
      'CRM, Marketing Tools, Project Management'
    ]
  };

  // Find the most relevant template based on job title
  const matchingTitle = Object.keys(skillTemplates).find(title => 
    jobTitle.toLowerCase().includes(title) || title.includes(jobTitle.toLowerCase())
  );

  const skills = matchingTitle 
    ? skillTemplates[matchingTitle]
    : [
        'Project Management, Team Leadership, Strategic Planning',
        'Communication, Problem Solving, Decision Making',
        'Stakeholder Management, Process Improvement',
        'Analytics, Reporting, Documentation',
        'Cross-functional Collaboration, Time Management'
      ];

  const selectedSkills = skills[Math.floor(Math.random() * skills.length)];

  return {
    content: selectedSkills,
    alternatives: skills.slice(0, 2),
    suggestions: [
      'Add technical skills specific to your role',
      'Include relevant certifications',
      'Highlight both hard and soft skills',
      'Focus on in-demand industry skills'
    ]
  };
};