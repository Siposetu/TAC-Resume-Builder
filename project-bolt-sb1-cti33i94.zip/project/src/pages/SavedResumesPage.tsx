import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useResume } from '../context/ResumeContext';
import { getSavedResumes, deleteSavedResume, loadSavedResume, SavedResume } from '../utils/storage';
import { FileText, Trash2, Copy, Calendar, Edit2 } from 'lucide-react';

const SavedResumesPage: React.FC = () => {
  const [savedResumes, setSavedResumes] = React.useState<SavedResume[]>([]);
  const { updateResumeData } = useResume();
  const navigate = useNavigate();

  React.useEffect(() => {
    setSavedResumes(getSavedResumes());
  }, []);

  const handleLoadResume = (id: string) => {
    const resume = loadSavedResume(id);
    if (resume) {
      updateResumeData(resume);
      navigate('/builder');
    }
  };

  const handleDeleteResume = (id: string) => {
    if (window.confirm('Are you sure you want to delete this resume?')) {
      deleteSavedResume(id);
      setSavedResumes(getSavedResumes());
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className="py-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Saved Resumes</h1>
          <p className="mt-2 text-lg text-gray-600">
            Access and manage your previously saved resumes
          </p>
        </div>

        {savedResumes.length === 0 ? (
          <div className="text-center py-12 bg-white rounded-lg shadow">
            <FileText className="mx-auto h-12 w-12 text-gray-400" />
            <h3 className="mt-2 text-sm font-medium text-gray-900">No resumes saved</h3>
            <p className="mt-1 text-sm text-gray-500">
              Start by creating a new resume and saving it for future access.
            </p>
            <div className="mt-6">
              <button
                onClick={() => navigate('/builder')}
                className="btn btn-primary"
              >
                Create New Resume
              </button>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {savedResumes.map((resume) => (
              <div
                key={resume.id}
                className="bg-white overflow-hidden shadow rounded-lg border border-gray-200 hover:border-primary-500 transition-colors"
              >
                <div className="p-5">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <FileText className="h-5 w-5 text-primary-600" />
                      <h3 className="ml-2 text-lg font-medium text-gray-900">
                        {resume.name}
                      </h3>
                    </div>
                  </div>
                  
                  <div className="mt-4 text-sm text-gray-500">
                    <p className="font-medium text-gray-900">{resume.personalInfo.firstName} {resume.personalInfo.lastName}</p>
                    <p>{resume.personalInfo.title}</p>
                  </div>

                  <div className="mt-4 flex items-center text-xs text-gray-500">
                    <Calendar className="h-4 w-4 mr-1" />
                    <span>Saved on {formatDate(resume.savedAt)}</span>
                  </div>
                </div>

                <div className="bg-gray-50 px-5 py-3 border-t border-gray-200">
                  <div className="flex justify-between items-center">
                    <button
                      onClick={() => handleLoadResume(resume.id)}
                      className="text-sm text-primary-600 hover:text-primary-900 font-medium flex items-center"
                    >
                      <Edit2 className="h-4 w-4 mr-1" />
                      Edit Resume
                    </button>
                    <button
                      onClick={() => handleDeleteResume(resume.id)}
                      className="text-sm text-error-600 hover:text-error-900 font-medium flex items-center"
                    >
                      <Trash2 className="h-4 w-4 mr-1" />
                      Delete
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default SavedResumesPage;