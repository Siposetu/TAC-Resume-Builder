import React from 'react';
import { Link } from 'react-router-dom';
import { FileText, Cpu, Download, Layout, CheckCircle, Heart } from 'lucide-react';

const HomePage: React.FC = () => {
  return (
    <div className="bg-gradient-to-br from-primary-50 to-accent-50">
      {/* Hero Section */}
      <div className="pt-16 pb-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl font-extrabold text-gray-900 sm:text-5xl sm:tracking-tight lg:text-6xl">
              TAC Resume Builder
            </h1>
            <p className="mt-5 max-w-xl mx-auto text-xl text-gray-600">
              Create professional, ATS-friendly resumes with AI-powered content generation
            </p>
            <div className="mt-8 flex justify-center">
              <Link
                to="/builder"
                className="btn btn-primary px-8 py-3 text-base font-medium rounded-md shadow-md"
              >
                Build Your Resume
              </Link>
              <Link
                to="/preview"
                className="ml-4 btn btn-outline px-8 py-3 text-base font-medium rounded-md shadow-sm"
              >
                Preview & Export
              </Link>
            </div>
          </div>
        </div>
      </div>
      
      {/* Features Section */}
      <div className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-extrabold text-gray-900">
              Smart Resume Building Features
            </h2>
            <p className="mt-4 max-w-2xl mx-auto text-xl text-gray-500">
              Everything you need to create a standout resume that gets you noticed
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="flex flex-col">
              <Link 
                to="/builder"
                className="bg-gray-50 rounded-lg p-6 shadow-sm border border-gray-200 hover:shadow-md transition-shadow duration-300 group flex-grow"
              >
                <div className="h-12 w-12 rounded-md bg-primary-100 text-primary-600 flex items-center justify-center mb-4 group-hover:bg-primary-200">
                  <Cpu className="h-6 w-6" />
                </div>
                <h3 className="text-lg font-medium text-gray-900 group-hover:text-primary-600">AI Content Generation</h3>
                <p className="mt-2 text-base text-gray-500">
                  Transform basic information into professional summaries, job descriptions, and skill statements with AI assistance.
                </p>
              </Link>
              <a 
                href="https://www.google.com/search?q=AI+resume+content+generation+tools"
                target="_blank"
                rel="noopener noreferrer"
                className="mt-2 text-sm text-primary-600 hover:text-primary-800"
              >
                Learn more about AI resume tools →
              </a>
            </div>
            
            <div className="flex flex-col">
              <Link 
                to="/builder"
                className="bg-gray-50 rounded-lg p-6 shadow-sm border border-gray-200 hover:shadow-md transition-shadow duration-300 group flex-grow"
              >
                <div className="h-12 w-12 rounded-md bg-accent-100 text-accent-600 flex items-center justify-center mb-4 group-hover:bg-accent-200">
                  <CheckCircle className="h-6 w-6" />
                </div>
                <h3 className="text-lg font-medium text-gray-900 group-hover:text-accent-600">ATS Optimization</h3>
                <p className="mt-2 text-base text-gray-500">
                  Get industry-specific keyword suggestions to ensure your resume passes through Applicant Tracking Systems.
                </p>
              </Link>
              <a 
                href="https://www.google.com/search?q=ATS+friendly+resume+tips"
                target="_blank"
                rel="noopener noreferrer"
                className="mt-2 text-sm text-accent-600 hover:text-accent-800"
              >
                Learn about ATS-friendly resumes →
              </a>
            </div>
            
            <div className="flex flex-col">
              <Link 
                to="/preview"
                className="bg-gray-50 rounded-lg p-6 shadow-sm border border-gray-200 hover:shadow-md transition-shadow duration-300 group flex-grow"
              >
                <div className="h-12 w-12 rounded-md bg-secondary-100 text-secondary-600 flex items-center justify-center mb-4 group-hover:bg-secondary-200">
                  <Layout className="h-6 w-6" />
                </div>
                <h3 className="text-lg font-medium text-gray-900 group-hover:text-secondary-600">Professional Templates</h3>
                <p className="mt-2 text-base text-gray-500">
                  Choose from multiple professional resume designs with customizable colors and layouts.
                </p>
              </Link>
              <a 
                href="https://www.google.com/search?q=professional+resume+templates+examples"
                target="_blank"
                rel="noopener noreferrer"
                className="mt-2 text-sm text-secondary-600 hover:text-secondary-800"
              >
                Explore resume template examples →
              </a>
            </div>
            
            <div className="flex flex-col">
              <Link 
                to="/preview"
                className="bg-gray-50 rounded-lg p-6 shadow-sm border border-gray-200 hover:shadow-md transition-shadow duration-300 group flex-grow"
              >
                <div className="h-12 w-12 rounded-md bg-success-100 text-success-600 flex items-center justify-center mb-4 group-hover:bg-success-200">
                  <Download className="h-6 w-6" />
                </div>
                <h3 className="text-lg font-medium text-gray-900 group-hover:text-success-600">Multiple Export Options</h3>
                <p className="mt-2 text-base text-gray-500">
                  Export your resume in PDF, DOCX, or HTML formats while maintaining consistent professional formatting.
                </p>
              </Link>
              <a 
                href="https://www.google.com/search?q=best+resume+file+formats+for+job+applications"
                target="_blank"
                rel="noopener noreferrer"
                className="mt-2 text-sm text-success-600 hover:text-success-800"
              >
                Learn about resume file formats →
              </a>
            </div>
            
            <div className="flex flex-col">
              <Link 
                to="/builder"
                className="bg-gray-50 rounded-lg p-6 shadow-sm border border-gray-200 hover:shadow-md transition-shadow duration-300 group flex-grow"
              >
                <div className="h-12 w-12 rounded-md bg-warning-100 text-warning-600 flex items-center justify-center mb-4 group-hover:bg-warning-200">
                  <FileText className="h-6 w-6" />
                </div>
                <h3 className="text-lg font-medium text-gray-900 group-hover:text-warning-600">Real-time Preview</h3>
                <p className="mt-2 text-base text-gray-500">
                  See how your resume looks as you build it with a live preview that updates in real-time.
                </p>
              </Link>
              <a 
                href="https://www.google.com/search?q=importance+of+resume+formatting+and+layout"
                target="_blank"
                rel="noopener noreferrer"
                className="mt-2 text-sm text-warning-600 hover:text-warning-800"
              >
                Read about resume formatting →
              </a>
            </div>
            
            <div className="flex flex-col">
              <Link 
                to="/builder"
                className="bg-gray-50 rounded-lg p-6 shadow-sm border border-gray-200 hover:shadow-md transition-shadow duration-300 group flex-grow"
              >
                <div className="h-12 w-12 rounded-md bg-error-100 text-error-600 flex items-center justify-center mb-4 group-hover:bg-error-200">
                  <Cpu className="h-6 w-6" />
                </div>
                <h3 className="text-lg font-medium text-gray-900 group-hover:text-error-600">Smart Suggestions</h3>
                <p className="mt-2 text-base text-gray-500">
                  Receive intelligent recommendations to improve your resume content based on industry best practices.
                </p>
              </Link>
              <a 
                href="https://www.google.com/search?q=resume+writing+tips+and+best+practices"
                target="_blank"
                rel="noopener noreferrer"
                className="mt-2 text-sm text-error-600 hover:text-error-800"
              >
                Discover resume writing tips →
              </a>
            </div>
          </div>
        </div>
      </div>
      
      {/* How It Works Section */}
      <div className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-extrabold text-gray-900">
              How It Works
            </h2>
            <p className="mt-4 max-w-2xl mx-auto text-xl text-gray-500">
              Create a professional resume in just a few simple steps
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="relative">
              <div className="absolute top-0 left-1/2 -ml-0.5 w-1 h-full bg-primary-200 hidden md:block"></div>
              <div className="relative bg-white rounded-lg p-6 shadow-sm border border-gray-200">
                <div className="absolute top-6 left-1/2 -ml-5 w-10 h-10 rounded-full bg-primary-600 text-white flex items-center justify-center font-bold text-lg z-10 shadow-md hidden md:flex">1</div>
                <div className="md:ml-8 relative">
                  <h3 className="text-lg font-medium text-gray-900 mb-2">Enter Your Information</h3>
                  <p className="text-gray-600">
                    Fill in your personal details, work experience, education, and skills. Use our AI assistant to generate professional content.
                  </p>
                </div>
              </div>
            </div>
            
            <div className="relative">
              <div className="absolute top-0 left-1/2 -ml-0.5 w-1 h-full bg-primary-200 hidden md:block"></div>
              <div className="relative bg-white rounded-lg p-6 shadow-sm border border-gray-200">
                <div className="absolute top-6 left-1/2 -ml-5 w-10 h-10 rounded-full bg-primary-600 text-white flex items-center justify-center font-bold text-lg z-10 shadow-md hidden md:flex">2</div>
                <div className="md:ml-8 relative">
                  <h3 className="text-lg font-medium text-gray-900 mb-2">Customize Your Resume</h3>
                  <p className="text-gray-600">
                    Choose from multiple professional templates and customize colors to match your personal style.
                  </p>
                </div>
              </div>
            </div>
            
            <div className="relative">
              <div className="relative bg-white rounded-lg p-6 shadow-sm border border-gray-200">
                <div className="absolute top-6 left-1/2 -ml-5 w-10 h-10 rounded-full bg-primary-600 text-white flex items-center justify-center font-bold text-lg z-10 shadow-md hidden md:flex">3</div>
                <div className="md:ml-8 relative">
                  <h3 className="text-lg font-medium text-gray-900 mb-2">Export & Apply</h3>
                  <p className="text-gray-600">
                    Download your polished resume in PDF, DOCX, or HTML format and start applying for jobs with confidence.
                  </p>
                </div>
              </div>
            </div>
          </div>
          
          <div className="text-center mt-12">
            <Link
              to="/builder"
              className="btn btn-primary px-8 py-3 text-base font-medium rounded-md shadow-md"
            >
              Start Building Now
            </Link>
          </div>
        </div>
      </div>
      
      {/* Testimonials Section */}
      <div className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-extrabold text-gray-900">
              What Our Users Say
            </h2>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-gray-50 rounded-lg p-6 shadow-sm border border-gray-200">
              <div className="flex items-center mb-4">
                <div className="h-10 w-10 rounded-full bg-primary-100 flex items-center justify-center">
                  <span className="text-primary-800 font-bold">JD</span>
                </div>
                <div className="ml-3">
                  <h3 className="text-lg font-medium text-gray-900">John D.</h3>
                  <p className="text-sm text-gray-500">Software Engineer</p>
                </div>
              </div>
              <p className="text-gray-600">
                "The AI content generation saved me hours of work. I received three interview calls within a week of sending out my new resume!"
              </p>
            </div>
            
            <div className="bg-gray-50 rounded-lg p-6 shadow-sm border border-gray-200">
              <div className="flex items-center mb-4">
                <div className="h-10 w-10 rounded-full bg-accent-100 flex items-center justify-center">
                  <span className="text-accent-800 font-bold">SM</span>
                </div>
                <div className="ml-3">
                  <h3 className="text-lg font-medium text-gray-900">Sarah M.</h3>
                  <p className="text-sm text-gray-500">Marketing Manager</p>
                </div>
              </div>
              <p className="text-gray-600">
                "The ATS optimization features helped my resume get noticed. The templates are beautiful and professional. Highly recommend!"
              </p>
            </div>
            
            <div className="bg-gray-50 rounded-lg p-6 shadow-sm border border-gray-200">
              <div className="flex items-center mb-4">
                <div className="h-10 w-10 rounded-full bg-secondary-100 flex items-center justify-center">
                  <span className="text-secondary-800 font-bold">RK</span>
                </div>
                <div className="ml-3">
                  <h3 className="text-lg font-medium text-gray-900">Robert K.</h3>
                  <p className="text-sm text-gray-500">Project Manager</p>
                </div>
              </div>
              <p className="text-gray-600">
                "The multiple export options were incredibly useful. I needed different formats for different applications, and this tool made it simple."
              </p>
            </div>
          </div>
        </div>
      </div>
      
      {/* CTA Section */}
      <div className="py-16 bg-primary-600">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-3xl font-extrabold text-white">
              Ready to create your professional resume?
            </h2>
            <p className="mt-4 max-w-2xl mx-auto text-xl text-primary-100">
              Start building your future today with our AI-powered resume builder.
            </p>
            <div className="mt-8">
              <Link
                to="/builder"
                className="btn inline-flex items-center justify-center px-8 py-3 border border-transparent text-base font-medium rounded-md text-primary-700 bg-white hover:bg-primary-50 shadow-md"
              >
                Build Your Resume Now
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HomePage;