import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { UserCircle, Briefcase, GraduationCap, Award, ArrowRight, ArrowLeft, CheckCircle } from 'lucide-react';
import PersonalInfoForm from '../components/builder/PersonalInfoForm';
import ExperienceForm from '../components/builder/ExperienceForm';
import EducationForm from '../components/builder/EducationForm';
import SkillsForm from '../components/builder/SkillsForm';

const BuilderPage: React.FC = () => {
  const [activeStep, setActiveStep] = useState(0);
  
  const steps = [
    { 
      id: 'personal', 
      name: 'Personal Info', 
      icon: UserCircle,
      component: <PersonalInfoForm />
    },
    { 
      id: 'experience', 
      name: 'Experience', 
      icon: Briefcase,
      component: <ExperienceForm />
    },
    { 
      id: 'education', 
      name: 'Education', 
      icon: GraduationCap,
      component: <EducationForm />
    },
    { 
      id: 'skills', 
      name: 'Skills', 
      icon: Award,
      component: <SkillsForm />
    }
  ];
  
  const handleNext = () => {
    setActiveStep(prev => Math.min(prev + 1, steps.length - 1));
  };
  
  const handlePrev = () => {
    setActiveStep(prev => Math.max(prev - 1, 0));
  };
  
  return (
    <div className="py-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Resume Builder</h1>
          <p className="mt-2 text-lg text-gray-600">
            Complete the sections below to create your professional resume
          </p>
        </div>
        
        {/* Progress Tabs */}
        <div className="mb-8">
          <div className="border-b border-gray-200">
            <nav className="flex -mb-px">
              {steps.map((step, index) => {
                const Icon = step.icon;
                return (
                  <button
                    key={step.id}
                    onClick={() => setActiveStep(index)}
                    className={`${
                      activeStep === index
                        ? 'border-primary-500 text-primary-600'
                        : index < activeStep
                        ? 'border-green-500 text-green-600'
                        : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                    } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm flex items-center mr-8 transition-colors`}
                  >
                    {index < activeStep ? (
                      <CheckCircle className="h-5 w-5 mr-2" />
                    ) : (
                      <Icon className="h-5 w-5 mr-2" />
                    )}
                    {step.name}
                  </button>
                );
              })}
            </nav>
          </div>
        </div>
        
        {/* Current Step Form */}
        <div className="mb-8">
          {steps[activeStep].component}
        </div>
        
        {/* Navigation Buttons */}
        <div className="flex justify-between">
          <button
            type="button"
            onClick={handlePrev}
            disabled={activeStep === 0}
            className={`btn ${
              activeStep === 0 ? 'opacity-50 cursor-not-allowed' : 'btn-outline'
            } inline-flex items-center`}
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Previous
          </button>
          
          <div>
            {activeStep === steps.length - 1 ? (
              <Link
                to="/preview"
                className="btn btn-primary inline-flex items-center"
              >
                Preview & Export
                <ArrowRight className="h-4 w-4 ml-2" />
              </Link>
            ) : (
              <button
                type="button"
                onClick={handleNext}
                className="btn btn-primary inline-flex items-center"
              >
                Next
                <ArrowRight className="h-4 w-4 ml-2" />
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default BuilderPage;