import React from 'react';
import ResumePreview from '../components/preview/ResumePreview';

const PreviewPage: React.FC = () => {
  return (
    <div>
      <ResumePreview />
    </div>
  );
};

export default PreviewPage;