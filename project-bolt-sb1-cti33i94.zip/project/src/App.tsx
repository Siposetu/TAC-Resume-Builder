import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { ResumeProvider } from './context/ResumeContext';
import Layout from './components/common/Layout';
import HomePage from './pages/HomePage';
import BuilderPage from './pages/BuilderPage';
import PreviewPage from './pages/PreviewPage';
import SavedResumesPage from './pages/SavedResumesPage';

function App() {
  return (
    <ResumeProvider>
      <Router>
        <Layout>
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/builder" element={<BuilderPage />} />
            <Route path="/preview" element={<PreviewPage />} />
            <Route path="/saved" element={<SavedResumesPage />} />
          </Routes>
        </Layout>
      </Router>
    </ResumeProvider>
  );
}

export default App;